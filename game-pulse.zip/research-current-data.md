# Pesquisa de Dados Atualizados - GamePulse

## League of Legends (Julho 2026)
- **Patch Atual**: 26.15 (7/28/2026)
- **Evento**: 2026 Fan Fest - Classic, Mayhem, Hall of Legends
- **Esports**: Worlds 2026 confirmado (15 Oct - 14 Nov)
- **Cidades Worlds**: Los Angeles, Allen (Texas), New York City
- **Links Oficiais**:
  - News: https://www.leagueoflegends.com/en-us/news/
  - Esports: https://lolesports.com/
  - Patch Notes: https://www.leagueoflegends.com/en-us/news/tags/patch-notes/

## Counter-Strike 2 (Julho 2026)
- **Temporada**: 5 (Iniciada em Julho 6-7, 2026)
- **Mudança de Mapa**: Cache adicionado, Overpass removido
- **Evento**: IEM Cologne Major 2026 (concluído em 22/06)
- **Próximo**: CS2 Premier Season 5 em andamento
- **Links Oficiais**:
  - News: https://www.counter-strike.net/news
  - Updates: https://www.counter-strike.net/news/updates
  - Steam: https://store.steampowered.com/news/app/730

## Marvel Rivals (Julho 2026)
- **Temporada Atual**: 9 - "The Mystery of Thebes"
- **Data Início**: 10 Julho 2026 (UTC)
- **Novo Herói**: Confirmado novo herói para Season 9
- **Novo Mapa**: Confirmado novo mapa para Season 9
- **Evento**: Path to Doomsday - Avengers: Age of Ultron (30 Julho)
- **Links Oficiais**:
  - News: https://www.marvelrivals.com/news/
  - Site Principal: https://www.marvelrivals.com/m/
  - Eventos: https://marvelrivals.gg/events/

## Fortnite (Junho-Julho 2026)
- **Capítulo**: 7
- **Temporada Atual**: Season 3 - "Runners"
- **Data Início**: 6 Junho 2026
- **Evento Fim**: Shattered Live Event (5 Junho 2026)
- **Festival**: Lil Tecca - Fortnite Festival Season 15
- **Links Oficiais**:
  - News: https://www.fortnite.com/news
  - Festival: Fortnite Festival Season 15

## Warhammer Darktide (Junho 2026)
- **Patch Atual**: 1.12.0 (Free Update)
- **Novo Classe**: Skitarii (lançado 23 Junho 2026)
- **Status**: Recebendo atualizações regulares
- **Links Oficiais**:
  - News: https://www.playdarktide.com/news

## Space Marine 2 (Junho 2026)
- **Patch Atual**: 13 (Purgation Update)
- **Conteúdo**: Nova missão PvE, atualização Siege Mode
- **Próximo**: Update 12 em desenvolvimento
- **Roadmap**: Holiday 2026 (Thanksgiving - Christmas)
- **Links Oficiais**:
  - Community: https://community.focus-entmt.com/focus-entertainment/space-marine-2/

## Observações Importantes
- Todos os dados são de Julho-Agosto 2026
- Links apontam para sites oficiais e confiáveis
- Informações verificadas em múltiplas fontes
- Recomenda-se atualizar dados a cada 2 semanas
