import { useEffect, useState, useCallback } from 'react';

interface UseAutoRefreshOptions {
  intervalMinutes?: number;
  onRefresh?: () => Promise<void>;
}

export function useAutoRefresh({
  intervalMinutes = 7,
  onRefresh,
}: UseAutoRefreshOptions = {}) {
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = useCallback(async () => {
    if (isRefreshing) return;
    
    setIsRefreshing(true);
    try {
      if (onRefresh) {
        await onRefresh();
      }
      setLastUpdated(new Date());
    } catch (error) {
      console.error('Auto-refresh error:', error);
    } finally {
      setIsRefreshing(false);
    }
  }, [onRefresh, isRefreshing]);

  useEffect(() => {
    // Set up interval for auto-refresh
    const intervalMs = intervalMinutes * 60 * 1000;
    const interval = setInterval(() => {
      handleRefresh();
    }, intervalMs);

    return () => clearInterval(interval);
  }, [intervalMinutes, handleRefresh]);

  return {
    lastUpdated,
    isRefreshing,
    refresh: handleRefresh,
  };
}
