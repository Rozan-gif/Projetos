import { useState, useCallback, useRef } from 'react';

interface NotificationState {
  news: number;
  events: number;
  drops: number;
}

export function useNotificationBadges() {
  const [badges, setBadges] = useState<NotificationState>({
    news: 0,
    events: 0,
    drops: 0,
  });

  const prevCountsRef = useRef<NotificationState>({
    news: 0,
    events: 0,
    drops: 0,
  });

  // Update badge count when new data arrives
  const updateBadges = useCallback((newCounts: Partial<NotificationState>) => {
    setBadges(prev => {
      const updated = { ...prev, ...newCounts };
      
      // Calculate new items based on difference
      const newNews = (newCounts.news ?? prev.news) > prevCountsRef.current.news ? 1 : 0;
      const newEvents = (newCounts.events ?? prev.events) > prevCountsRef.current.events ? 1 : 0;
      const newDrops = (newCounts.drops ?? prev.drops) > prevCountsRef.current.drops ? 1 : 0;

      // Update ref with new counts (not in state to avoid dependency issues)
      prevCountsRef.current = updated;

      // Return updated badges
      return {
        news: newNews > 0 ? (newCounts.news ?? prev.news) : prev.news,
        events: newEvents > 0 ? (newCounts.events ?? prev.events) : prev.events,
        drops: newDrops > 0 ? (newCounts.drops ?? prev.drops) : prev.drops,
      };
    });
  }, []);

  // Clear badge for a specific section
  const clearBadge = useCallback((section: keyof NotificationState) => {
    setBadges(prev => ({
      ...prev,
      [section]: 0,
    }));
    prevCountsRef.current[section] = 0;
  }, []);

  // Clear all badges
  const clearAll = useCallback(() => {
    setBadges({ news: 0, events: 0, drops: 0 });
    prevCountsRef.current = { news: 0, events: 0, drops: 0 };
  }, []);

  return {
    badges,
    updateBadges,
    clearBadge,
    clearAll,
  };
}
