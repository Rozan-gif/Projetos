export interface Game {
  id: number;
  slug: string;
  name: string;
  description?: string;
  officialUrl?: string;
  feedSources?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface GameEvent {
  id: number;
  gameId: number;
  title: string;
  description?: string;
  status: 'active' | 'upcoming' | 'ended';
  startDate?: Date;
  endDate?: Date;
  externalUrl?: string;
  source?: string;
  externalId?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface TwitchDrop {
  id: number;
  gameId: number;
  campaignId: string;
  title: string;
  description?: string;
  rewards?: string;
  startDate?: Date;
  endDate?: Date;
  status: 'active' | 'upcoming' | 'ended';
  watchUrl?: string;
  externalData?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface FeedArticle {
  id: number;
  gameId: number;
  title: string;
  description?: string;
  content?: string;
  author?: string;
  imageUrl?: string;
  externalUrl: string;
  source?: string;
  externalId?: string;
  publishedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}
