interface GameCardProps {
  game: any;
  selected?: boolean;
  onClick?: () => void;
  icon?: string;
}

export function GameCard({ game, selected, onClick, icon }: GameCardProps) {
  return (
    <button
      onClick={onClick}
      className={`p-4 border-2 rounded transition-all text-left ${
        selected
          ? 'border-accent [background-color:rgba(0,255,255,0.1)] text-accent'
          : 'border-border bg-card/30 text-muted-foreground hover:border-accent/50'
      }`}
    >
      {icon && (
        <div className="[margin-bottom:0.75rem] overflow-hidden rounded h-16 w-16 flex items-center justify-center bg-background/50">
          <img
            src={icon}
            alt={game.name}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        </div>
      )}
      <h3 className="font-semibold text-lg">{game.name}</h3>
      <p className="text-sm opacity-75">{game.description}</p>
    </button>
  );
}
