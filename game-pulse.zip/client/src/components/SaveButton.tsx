import { Bookmark, BookmarkCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState, useEffect } from 'react';
import { toast } from 'sonner';

interface SaveButtonProps {
  itemId: number;
  title: string;
  onSaveChange?: (isSaved: boolean) => void;
  size?: 'sm' | 'lg';
}

const SAVED_ITEMS_KEY = 'gamepulse_saved_items';

export function SaveButton({ itemId, title, onSaveChange, size = 'sm' }: SaveButtonProps) {
  const [isSaved, setIsSaved] = useState(false);

  // Load saved state on mount
  useEffect(() => {
    const saved = localStorage.getItem(SAVED_ITEMS_KEY);
    const savedItems = saved ? JSON.parse(saved) : [];
    const isItemSaved = savedItems.some((item: any) => item.id === itemId);
    setIsSaved(isItemSaved);
  }, [itemId]);

  const handleSave = () => {
    const saved = localStorage.getItem(SAVED_ITEMS_KEY);
    let savedItems = saved ? JSON.parse(saved) : [];

    if (isSaved) {
      // Remove from saved
      savedItems = savedItems.filter((item: any) => item.id !== itemId);
      setIsSaved(false);
      toast.success('📌 Removido dos salvos', {
        description: 'Você pode salvá-la novamente a qualquer momento',
        duration: 2500,
      });
    } else {
      // Add to saved
      savedItems.push({
        id: itemId,
        title,
        savedAt: new Date().toISOString(),
      });
      setIsSaved(true);
      toast.success('✅ Salvo com sucesso!', {
        description: 'Acesse a aba "Salvos" para ler depois',
        duration: 2500,
      });
    }

    localStorage.setItem(SAVED_ITEMS_KEY, JSON.stringify(savedItems));
    onSaveChange?.(!isSaved);
  };

  const sizeClass = size === 'sm' ? 'w-8 h-8' : 'w-10 h-10';
  const iconSize = size === 'sm' ? 16 : 20;
  const buttonSize = size === 'sm' ? 'sm' : 'lg';

  return (
    <Button
      variant="ghost"
      size={buttonSize}
      onClick={handleSave}
      className={`${sizeClass} p-0 text-accent hover:[background-color:rgba(0,255,255,0.1)]`}
      title={isSaved ? 'Remover dos salvos' : 'Salvar para ler depois'}
    >
      {isSaved ? (
        <BookmarkCheck size={iconSize} className="text-accent" />
      ) : (
        <Bookmark size={iconSize} />
      )}
    </Button>
  );
}

export function getSavedItems() {
  const saved = localStorage.getItem(SAVED_ITEMS_KEY);
  return saved ? JSON.parse(saved) : [];
}

export function isSavedItem(itemId: number): boolean {
  const savedItems = getSavedItems();
  return savedItems.some((item: any) => item.id === itemId);
}
