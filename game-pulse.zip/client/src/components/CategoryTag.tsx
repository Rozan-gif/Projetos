interface CategoryTagProps {
  category: 'twitch-drop' | 'tournament' | 'update' | 'event' | 'maintenance' | 'news' | 'other';
  size?: 'sm' | 'md';
}

const CATEGORY_DISPLAY: Record<string, { label: string; color: string; bgColor: string; darkBgColor: string }> = {
  'twitch-drop': {
    label: 'Twitch Drop',
    color: '#9146ff',
    bgColor: 'rgba(145, 70, 255, 0.1)',
    darkBgColor: 'rgba(145, 70, 255, 0.25)',
  },
  'tournament': {
    label: 'Torneio',
    color: '#ff6b00',
    bgColor: 'rgba(255, 107, 0, 0.1)',
    darkBgColor: 'rgba(255, 107, 0, 0.25)',
  },
  'update': {
    label: 'Atualização',
    color: '#00d4ff',
    bgColor: 'rgba(0, 212, 255, 0.1)',
    darkBgColor: 'rgba(0, 212, 255, 0.25)',
  },
  'event': {
    label: 'Evento',
    color: '#ff00ff',
    bgColor: 'rgba(255, 0, 255, 0.1)',
    darkBgColor: 'rgba(255, 0, 255, 0.25)',
  },
  'maintenance': {
    label: 'Manutenção',
    color: '#ffff00',
    bgColor: 'rgba(255, 255, 0, 0.1)',
    darkBgColor: 'rgba(255, 255, 0, 0.25)',
  },
  'news': {
    label: 'Notícia',
    color: '#00ff00',
    bgColor: 'rgba(0, 255, 0, 0.1)',
    darkBgColor: 'rgba(0, 255, 0, 0.25)',
  },
  'other': {
    label: 'Outro',
    color: '#808080',
    bgColor: 'rgba(128, 128, 128, 0.1)',
    darkBgColor: 'rgba(128, 128, 128, 0.25)',
  },
};

export function CategoryTag({ category, size = 'sm' }: CategoryTagProps) {
  const display = CATEGORY_DISPLAY[category] || CATEGORY_DISPLAY['other'];
  const sizeClass = size === 'sm' ? 'text-xs [padding-left:0.5rem][padding-right:0.5rem][padding-top:0.25rem][padding-bottom:0.25rem]' : 'text-sm [padding-left:0.75rem][padding-right:0.75rem][padding-top:0.5rem][padding-bottom:0.5rem]';
  const isDark = typeof window !== 'undefined' && document.documentElement.classList.contains('dark');

  return (
    <span
      className={`inline-block rounded font-semibold whitespace-nowrap ${sizeClass}`}
      style={{
        color: display.color,
        backgroundColor: isDark ? display.darkBgColor : display.bgColor,
        border: `1px solid ${display.color}`,
      }}
    >
      {display.label}
    </span>
  );
}
