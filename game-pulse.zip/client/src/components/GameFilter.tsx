import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';

interface GameFilterProps {
  games: Array<{ id: number; name: string; slug: string }>;
  selectedGameIds: number[];
  onFilterChange: (gameIds: number[]) => void;
  showAllOption?: boolean;
}

export function GameFilter({
  games,
  selectedGameIds,
  onFilterChange,
  showAllOption = true,
}: GameFilterProps) {
  const [isOpen, setIsOpen] = useState(false);

  const handleToggleGame = (gameId: number) => {
    const newSelected = selectedGameIds.includes(gameId)
      ? selectedGameIds.filter(id => id !== gameId)
      : [...selectedGameIds, gameId];
    onFilterChange(newSelected);
  };

  const handleSelectAll = () => {
    onFilterChange(games.map(g => g.id));
  };

  const handleClearAll = () => {
    onFilterChange([]);
  };

  const selectedCount = selectedGameIds.length;
  const allSelected = selectedCount === games.length;

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="px-4 py-2 border-2 border-accent text-accent rounded hover:[background-color:rgba(0,255,255,0.1)] transition-all flex items-center gap-2"
      >
        <span className="text-sm font-semibold">
          Filtrar Jogos {selectedCount > 0 && `(${selectedCount})`}
        </span>
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 mt-2 bg-card border-2 border-accent rounded shadow-lg z-50 min-w-64">
          <div className="p-4">
            <div className="flex items-center justify-between [margin-bottom:1rem]">
              <h3 className="font-semibold text-foreground">Selecione Jogos</h3>
              <button
                onClick={() => setIsOpen(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X size={18} />
              </button>
            </div>

            <div className="space-y-2 [margin-bottom:1rem]">
              {games.map(game => (
                <label
                  key={game.id}
                  className="flex items-center gap-2 cursor-pointer hover:bg-background/50 p-2 rounded transition-colors"
                >
                  <input
                    type="checkbox"
                    checked={selectedGameIds.includes(game.id)}
                    onChange={() => handleToggleGame(game.id)}
                    className="w-4 h-4 cursor-pointer"
                  />
                  <span className="text-sm text-foreground">{game.name}</span>
                </label>
              ))}
            </div>

            <div className="flex gap-2 pt-2 border-t border-border">
              <Button
                size="sm"
                variant="outline"
                onClick={handleSelectAll}
                disabled={allSelected}
                className="flex-1 text-xs border-accent text-accent hover:[background-color:rgba(0,255,255,0.1)]"
              >
                Selecionar Tudo
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={handleClearAll}
                disabled={selectedCount === 0}
                className="flex-1 text-xs border-accent text-accent hover:[background-color:rgba(0,255,255,0.1)]"
              >
                Limpar
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
