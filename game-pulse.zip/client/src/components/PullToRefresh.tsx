import { useEffect, useRef, useState } from 'react';
import { RefreshCw } from 'lucide-react';

interface PullToRefreshProps {
  onRefresh: () => Promise<void>;
  children: React.ReactNode;
}

export function PullToRefresh({ onRefresh, children }: PullToRefreshProps) {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const startYRef = useRef(0);
  const scrollTopRef = useRef(0);

  const PULL_THRESHOLD = 80;

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleTouchStart = (e: TouchEvent) => {
      scrollTopRef.current = container.scrollTop;
      if (scrollTopRef.current === 0) {
        startYRef.current = e.touches[0].clientY;
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (scrollTopRef.current !== 0 || isRefreshing) return;

      const currentY = e.touches[0].clientY;
      const distance = currentY - startYRef.current;

      if (distance > 0) {
        setPullDistance(distance);
      }
    };

    const handleTouchEnd = async () => {
      if (pullDistance >= PULL_THRESHOLD && !isRefreshing) {
        setIsRefreshing(true);
        try {
          await onRefresh();
        } finally {
          setIsRefreshing(false);
        }
      }
      setPullDistance(0);
      startYRef.current = 0;
    };

    container.addEventListener('touchstart', handleTouchStart);
    container.addEventListener('touchmove', handleTouchMove, { passive: true });
    container.addEventListener('touchend', handleTouchEnd);

    return () => {
      container.removeEventListener('touchstart', handleTouchStart);
      container.removeEventListener('touchmove', handleTouchMove);
      container.removeEventListener('touchend', handleTouchEnd);
    };
  }, [pullDistance, isRefreshing, onRefresh]);

  const pullPercentage = Math.min((pullDistance / PULL_THRESHOLD) * 100, 100);
  const showRefreshIcon = pullDistance >= PULL_THRESHOLD || isRefreshing;

  return (
    <div
      ref={containerRef}
      className="relative overflow-y-auto"
      style={{
        height: '100%',
        transform: `translateY(${Math.min(pullDistance, PULL_THRESHOLD)}px)`,
        transition: isRefreshing || pullDistance === 0 ? 'transform 0.3s ease-out' : 'none',
      }}
    >
      {/* Pull Indicator */}
      {pullDistance > 0 && (
        <div className="absolute top-0 left-0 right-0 h-16 flex items-center justify-center bg-background border-b-2 border-accent/30 -translate-y-full">
          <div className="flex flex-col items-center gap-2">
            <RefreshCw
              size={20}
              className={`text-accent transition-all ${
                showRefreshIcon ? 'animate-spin' : ''
              }`}
              style={{
                opacity: pullPercentage / 100,
                transform: `rotate(${pullPercentage * 3.6}deg)`,
              }}
            />
            <span className="text-xs text-accent font-semibold">
              {isRefreshing ? 'Atualizando...' : 'Puxe para atualizar'}
            </span>
          </div>
        </div>
      )}

      {children}
    </div>
  );
}
