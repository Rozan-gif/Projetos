import { useLocation } from 'wouter';
import { Home, Newspaper, Heart, Calendar, Settings } from 'lucide-react';
import { useState, useEffect } from 'react';
import { NotificationBadge } from './NotificationBadge';
import { useNotificationBadges } from '@/hooks/useNotificationBadges';

export function BottomNav() {
  const [location] = useLocation();
  const [, navigate] = useLocation();
  const [savedCount, setSavedCount] = useState(0);
  const { badges, clearBadge } = useNotificationBadges();

  useEffect(() => {
    const saved = localStorage.getItem('savedArticles');
    if (saved) {
      try {
        const articles = JSON.parse(saved);
        setSavedCount(Object.keys(articles).length);
      } catch (e) {
        console.error('Error parsing saved articles:', e);
      }
    }
  }, []);

  const isActive = (path: string) => location === path;

  const handleNavClick = (path: string, section?: 'news' | 'events' | 'drops') => {
    navigate(path);
    if (section) {
      clearBadge(section);
    }
  };

  const navItems = [
    { path: '/dashboard', icon: Home, label: 'Dashboard', section: 'events' as const },
    { path: '/news', icon: Newspaper, label: 'Notícias', section: 'news' as const },
    { path: '/favorites', icon: Heart, label: 'Favoritos', badge: savedCount },
    { path: '/calendar', icon: Calendar, label: 'Calendário' },
    { path: '/settings', icon: Settings, label: 'Config' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-background border-t-2 border-accent md:hidden z-50">
      <div className="flex justify-around items-center h-16 px-2">
        {navItems.map(({ path, icon: Icon, label, badge, section }) => {
          const notificationCount = section ? badges[section] : 0;
          return (
            <button
              key={path}
              onClick={() => handleNavClick(path, section)}
              className={`flex flex-col items-center justify-center w-14 h-14 rounded transition-all relative ${
                isActive(path)
                  ? 'text-accent bg-accent/10 border-2 border-accent'
                  : 'text-muted-foreground hover:text-accent'
              }`}
              title={label}
            >
              <Icon size={20} />
              {/* Notification badge for new items */}
              {notificationCount > 0 && (
                <NotificationBadge show={true} count={notificationCount} />
              )}
              {/* Regular badge for saved count */}
              {badge !== undefined && badge > 0 && (
                <span className="absolute top-0 right-0 bg-accent text-background text-xs font-semibold rounded-full w-5 h-5 flex items-center justify-center">
                  {badge > 9 ? '9+' : badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
