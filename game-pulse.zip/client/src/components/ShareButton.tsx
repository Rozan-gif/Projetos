import { useState } from 'react';
import { Share2, Copy, MessageCircle, Mail, Twitter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface ShareButtonProps {
  title: string;
  description?: string;
  url?: string;
  size?: 'sm' | 'lg';
}

export function ShareButton({
  title,
  description,
  url = typeof window !== 'undefined' ? window.location.href : '',
  size = 'sm',
}: ShareButtonProps) {
  const [isOpen, setIsOpen] = useState(false);

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(url);
      toast.success('Link copiado para clipboard!');
      setIsOpen(false);
    } catch (error) {
      toast.error('Erro ao copiar link');
    }
  };

  const handleShareWhatsApp = () => {
    const text = `${title}${description ? '\n' + description : ''}\n\n${url}`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(whatsappUrl, '_blank');
    toast.success('Abrindo WhatsApp...');
    setIsOpen(false);
  };

  const handleShareTwitter = () => {
    const text = `${title}${description ? ' - ' + description : ''}`;
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
    window.open(twitterUrl, '_blank');
    toast.success('Abrindo Twitter/X...');
    setIsOpen(false);
  };

  const handleShareEmail = () => {
    const subject = `Confira: ${title}`;
    const body = `${title}${description ? '\n\n' + description : ''}\n\nLeia mais em: ${url}`;
    const mailtoUrl = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoUrl;
    toast.success('Abrindo cliente de email...');
    setIsOpen(false);
  };

  const sizeClass = size === 'sm' ? 'w-8 h-8' : 'w-10 h-10';
  const iconSize = size === 'sm' ? 16 : 20;
  const buttonSize = size === 'sm' ? 'sm' : 'lg';

  return (
    <div className="relative">
      <Button
        variant="ghost"
        size={buttonSize}
        onClick={() => setIsOpen(!isOpen)}
        className={`${sizeClass} p-0 text-accent hover:[background-color:rgba(0,255,255,0.1)]`}
        title="Compartilhar"
      >
        <Share2 size={iconSize} />
      </Button>

      {isOpen && (
        <div className="absolute right-0 top-full mt-2 bg-card border-2 border-accent rounded shadow-lg z-50 min-w-48">
          <div className="p-2 space-y-1">
            <button
              onClick={handleCopyLink}
              className="w-full flex items-center [gap:0.75rem] [padding-left:0.75rem][padding-right:0.75rem][padding-top:0.5rem][padding-bottom:0.5rem] text-sm text-foreground hover:[background-color:rgba(0,255,255,0.1)] rounded transition-colors"
            >
              <Copy size={16} className="text-accent" />
              Copiar Link
            </button>
            <button
              onClick={handleShareWhatsApp}
              className="w-full flex items-center [gap:0.75rem] [padding-left:0.75rem][padding-right:0.75rem][padding-top:0.5rem][padding-bottom:0.5rem] text-sm text-foreground hover:[background-color:rgba(0,255,255,0.1)] rounded transition-colors"
            >
              <MessageCircle size={16} style={{ color: '#25D366' }} />
              WhatsApp
            </button>
            <button
              onClick={handleShareTwitter}
              className="w-full flex items-center [gap:0.75rem] [padding-left:0.75rem][padding-right:0.75rem][padding-top:0.5rem][padding-bottom:0.5rem] text-sm text-foreground hover:[background-color:rgba(0,255,255,0.1)] rounded transition-colors"
            >
              <Twitter size={16} style={{ color: '#1DA1F2' }} />
              Twitter/X
            </button>
            <button
              onClick={handleShareEmail}
              className="w-full flex items-center [gap:0.75rem] [padding-left:0.75rem][padding-right:0.75rem][padding-top:0.5rem][padding-bottom:0.5rem] text-sm text-foreground hover:[background-color:rgba(0,255,255,0.1)] rounded transition-colors"
            >
              <Mail size={16} className="text-accent" />
              Email
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
