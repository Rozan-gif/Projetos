interface NotificationBadgeProps {
  show: boolean;
  count?: number;
}

export function NotificationBadge({ show, count }: NotificationBadgeProps) {
  if (!show) return null;

  return (
    <div className="absolute -top-1 -right-1 flex items-center justify-center">
      <style>{`
        @keyframes pulse-intense {
          0%, 100% {
            opacity: 1;
            transform: scale(1);
            box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7), inset 0 0 8px rgba(239, 68, 68, 0.5);
          }
          50% {
            opacity: 0.9;
            transform: scale(1.08);
            box-shadow: 0 0 0 10px rgba(239, 68, 68, 0), inset 0 0 12px rgba(239, 68, 68, 0.8);
          }
        }
        .pulse-badge {
          animation: pulse-intense 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
      `}</style>
      <div className="relative">
        {/* Pulsing glow background */}
        <div 
          className="absolute inset-0 bg-red-500 rounded-full opacity-40 blur-md"
          style={{
            animation: 'pulse-intense 2s cubic-bezier(0.4, 0, 0.6, 1) infinite'
          }}
        />
        
        {/* Main badge */}
        <div 
          className="pulse-badge relative w-5 h-5 bg-red-500 rounded-full flex items-center justify-center border-2 border-background"
          style={{
            boxShadow: '0 0 16px rgba(239, 68, 68, 0.9), 0 0 32px rgba(239, 68, 68, 0.5), inset 0 0 8px rgba(255, 100, 100, 0.4)'
          }}
        >
          {count && count > 0 && (
            <span className="text-xs font-bold text-white drop-shadow-lg">
              {count > 9 ? '9+' : count}
            </span>
          )}
          {!count && <div className="w-2 h-2 bg-red-200 rounded-full drop-shadow-lg" />}
        </div>
      </div>
    </div>
  );
}
