import { useEffect, useState } from 'react';
import { X, Clock, Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Notification {
  id: string;
  title: string;
  type: 'event' | 'news' | 'drop';
  timestamp: number;
  gameId: number;
  gameName: string;
}

interface NotificationHistoryProps {
  onClearAll?: () => void;
  onNotificationClick?: (notification: Notification) => void;
}

export function NotificationHistory({ onClearAll, onNotificationClick }: NotificationHistoryProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    // Load notifications from localStorage
    const stored = localStorage.getItem('notificationHistory');
    if (stored) {
      try {
        setNotifications(JSON.parse(stored));
      } catch (e) {
        console.error('Error parsing notification history:', e);
      }
    }
  }, []);

  const addNotification = (notification: Omit<Notification, 'id'>) => {
    const newNotification: Notification = {
      ...notification,
      id: `${Date.now()}-${Math.random()}`,
    };
    
    const updated = [newNotification, ...notifications].slice(0, 20); // Keep last 20
    setNotifications(updated);
    localStorage.setItem('notificationHistory', JSON.stringify(updated));
  };

  const clearHistory = () => {
    setNotifications([]);
    localStorage.removeItem('notificationHistory');
    onClearAll?.();
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'event': return '📅 Evento';
      case 'news': return '📰 Notícia';
      case 'drop': return '🎁 Drop';
      default: return '📢 Notificação';
    }
  };

  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Agora';
    if (diffMins < 60) return `${diffMins}m atrás`;
    if (diffHours < 24) return `${diffHours}h atrás`;
    if (diffDays < 7) return `${diffDays}d atrás`;
    return date.toLocaleDateString('pt-BR');
  };

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Bell size={18} className="text-accent" />
          <h3 className="text-lg font-semibold text-accent">Histórico de Notificações</h3>
        </div>
        {notifications.length > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={clearHistory}
            className="text-muted-foreground hover:text-accent"
          >
            <X size={16} className="mr-1" />
            Limpar
          </Button>
        )}
      </div>

      {notifications.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          <Bell size={32} className="mx-auto mb-2 opacity-50" />
          <p>Nenhuma notificação ainda</p>
        </div>
      ) : (
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {notifications.map((notification) => (
            <button
              key={notification.id}
              onClick={() => onNotificationClick?.(notification)}
              className="w-full p-3 rounded-lg border border-accent/30 bg-background/50 hover:bg-accent/10 transition-all text-left group"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm">{getTypeLabel(notification.type)}</span>
                    <span className="text-xs text-muted-foreground">{notification.gameName}</span>
                  </div>
                  <p className="text-sm font-medium text-accent truncate group-hover:text-accent/80">
                    {notification.title}
                  </p>
                </div>
                <div className="flex items-center gap-1 text-xs text-muted-foreground flex-shrink-0">
                  <Clock size={12} />
                  <span>{formatTime(notification.timestamp)}</span>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// Export function to add notifications from outside
export function useNotificationHistory() {
  return {
    addNotification: (notification: Omit<Notification, 'id'>) => {
      const stored = localStorage.getItem('notificationHistory') || '[]';
      const notifications = JSON.parse(stored) as Notification[];
      
      const newNotification: Notification = {
        ...notification,
        id: `${Date.now()}-${Math.random()}`,
      };
      
      const updated = [newNotification, ...notifications].slice(0, 20);
      localStorage.setItem('notificationHistory', JSON.stringify(updated));
    },
  };
}
