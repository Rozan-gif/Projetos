import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Loader2, Calendar, Gift, Newspaper, Settings, Sparkles } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useState, useMemo, useEffect } from 'react';
import { GameFilter } from '@/components/GameFilter';
import { CategoryTag } from '@/components/CategoryTag';
import { ShareButton } from '@/components/ShareButton';
import { ThemeToggle } from '@/components/ThemeToggle';
import { useAuth } from '@/_core/hooks/useAuth';
import { PullToRefresh } from '@/components/PullToRefresh';
import { useAutoRefresh } from '@/hooks/useAutoRefresh';
import { useNotificationBadges } from '@/hooks/useNotificationBadges';
import { NotificationHistory } from '@/components/NotificationHistory';

type TabType = 'events' | 'drops' | 'feed' | 'ended';

export default function DashboardTabs() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();

  const eventsQuery = trpc.dashboard.getEvents.useQuery();
  const dropsQuery = trpc.dashboard.getDrops.useQuery();
  const feedQuery = trpc.dashboard.getFeed.useQuery({ limit: 20 });
  const gamesQuery = trpc.games.list.useQuery();
  const summarizeMutation = trpc.ai.summarizeArticle.useMutation();
  const categorizeMutation = trpc.ai.categorizeContent.useMutation();
  
  const [summaries, setSummaries] = useState<Record<number, string>>({});
  const [categories, setCategories] = useState<Record<number, string>>({});
  const [selectedGameIds, setSelectedGameIds] = useState<number[]>([]);
  const [activeTab, setActiveTab] = useState<TabType>('events');

  // Auto-generate categories and summaries
  useEffect(() => {
    if (feedQuery.data && feedQuery.data.length > 0) {
      feedQuery.data.forEach(article => {
        if (!categories[article.id]) {
          generateCategory(article.id, article.title, article.description || undefined);
        }
        if (!summaries[article.id]) {
          generateSummary(article.id, article.title, article.description || undefined);
        }
      });
    }
  }, [feedQuery.data]);

  const handleRefresh = async () => {
    try {
      await feedQuery.refetch();
      await eventsQuery.refetch();
      await dropsQuery.refetch();
    } catch (error) {
      console.error('Error refreshing:', error);
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const generateSummary = async (id: number, title: string, description?: string) => {
    if (summaries[id]) return;
    try {
      const result = await summarizeMutation.mutateAsync({
        title,
        description,
      });
      setSummaries(prev => ({
        ...prev,
        [id]: result.summary,
      }));
    } catch (error) {
      console.error('Error generating summary:', error);
    }
  };

  const generateCategory = async (id: number, title: string, description?: string) => {
    if (categories[id]) return;
    try {
      const result = await categorizeMutation.mutateAsync({
        title,
        description,
      });
      setCategories(prev => ({
        ...prev,
        [id]: result.category,
      }));
    } catch (error) {
      console.error('Error categorizing content:', error);
    }
  };

  // Auto-refresh every 7 minutes
  const { lastUpdated, isRefreshing } = useAutoRefresh({
    intervalMinutes: 7,
    onRefresh: handleRefresh,
  });

  // Notification badges
  const { updateBadges, clearBadge } = useNotificationBadges();

  // Update badges when data changes
  useEffect(() => {
    if (eventsQuery.data && dropsQuery.data && feedQuery.data) {
      updateBadges({
        events: eventsQuery.data.length,
        drops: dropsQuery.data.length,
        news: feedQuery.data.length,
      });
    }
  }, [eventsQuery.data, dropsQuery.data, feedQuery.data, updateBadges]);

  // Filter data based on selected games
  const filteredEvents = useMemo(() => {
    if (!eventsQuery.data) return [];
    if (selectedGameIds.length === 0) return eventsQuery.data;
    return eventsQuery.data.filter(e => selectedGameIds.includes(e.gameId));
  }, [eventsQuery.data, selectedGameIds]);

  const filteredDrops = useMemo(() => {
    if (!dropsQuery.data) return [];
    if (selectedGameIds.length === 0) return dropsQuery.data;
    return dropsQuery.data.filter(d => selectedGameIds.includes(d.gameId));
  }, [dropsQuery.data, selectedGameIds]);

  const filteredFeed = useMemo(() => {
    if (!feedQuery.data) return [];
    if (selectedGameIds.length === 0) return feedQuery.data;
    return feedQuery.data.filter(a => selectedGameIds.includes(a.gameId));
  }, [feedQuery.data, selectedGameIds]);

  const activeEvents = useMemo(() => {
    return filteredEvents.filter(e => e.status === 'active' || e.status === 'upcoming');
  }, [filteredEvents]);

  const endedEvents = useMemo(() => {
    return filteredEvents.filter(e => e.status === 'ended');
  }, [filteredEvents]);

  const getStatusClass = (status: string) => {
    switch (status) {
      case 'active':
        return 'border-accent text-accent';
      case 'upcoming':
        return 'border-yellow-400 text-yellow-400';
      case 'completed':
        return 'border-gray-500 text-gray-500';
      default:
        return 'border-border text-foreground';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active':
        return 'EM ANDAMENTO';
      case 'upcoming':
        return 'PRÓXIMO';
      case 'completed':
        return 'ENCERRADO';
      default:
        return status.toUpperCase();
    }
  };

  return (
    <div className="min-h-screen bg-background px-4 py-6 sm:px-6 lg:px-8 pb-24 md:pb-8">
      <div className="max-w-7xl mx-auto">
        {/* Last Updated Indicator */}
        <div className="text-xs text-muted-foreground mb-4 text-center">
          Última atualização: {lastUpdated.toLocaleTimeString('pt-BR')}
          {isRefreshing && <span className="ml-2 text-accent">● Atualizando...</span>}
        </div>

        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl sm:text-4xl font-semibold text-accent neon-glow mb-2">
              GAMEPULSE
            </h1>
            <p className="text-sm sm:text-base text-muted-foreground">
              Bem-vindo, {user?.name || 'Usuário'}!
            </p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <ThemeToggle />
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/calendar')}
              className="border-accent text-accent hover:bg-accent/10"
            >
              <Calendar size={16} className="mr-2" />
              Calendário
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/news')}
              className="border-accent text-accent hover:bg-accent/10"
            >
              <Newspaper size={16} className="mr-2" />
              Notícias
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/settings')}
              className="border-accent text-accent hover:bg-accent/10"
            >
              <Settings size={16} className="mr-2" />
              Config
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="border-accent text-accent hover:bg-accent/10"
            >
              {isRefreshing ? 'Atualizando...' : 'Atualizar'}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => clearBadge('events')}
              className="border-accent text-accent hover:bg-accent/10"
            >
              ✓ Marcar Tudo como Lido
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleLogout}
              className="border-destructive text-destructive hover:bg-destructive/10"
            >
              Sair
            </Button>
          </div>
        </div>

        {/* Filter Section */}
        {gamesQuery.data && (
          <div className="mb-8">
            <GameFilter
              games={gamesQuery.data}
              selectedGameIds={selectedGameIds}
              onFilterChange={setSelectedGameIds}
            />
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-2 mb-6 border-b-2 border-border pb-4">
          <Button
            variant={activeTab === 'events' ? 'default' : 'outline'}
            onClick={() => setActiveTab('events')}
            className={`flex items-center gap-2 ${
              activeTab === 'events'
                ? 'bg-accent text-background'
                : 'border-accent text-accent hover:bg-accent/10'
            }`}
          >
            <Calendar size={18} />
            Eventos ({filteredEvents.length})
          </Button>
          <Button
            variant={activeTab === 'drops' ? 'default' : 'outline'}
            onClick={() => setActiveTab('drops')}
            className={`flex items-center gap-2 ${
              activeTab === 'drops'
                ? 'bg-accent text-background'
                : 'border-accent text-accent hover:bg-accent/10'
            }`}
          >
            <Gift size={18} />
            Drops ({filteredDrops.length})
          </Button>
          <Button
            variant={activeTab === 'feed' ? 'default' : 'outline'}
            onClick={() => setActiveTab('feed')}
            className={`flex items-center gap-2 ${
              activeTab === 'feed'
                ? 'bg-accent text-background'
                : 'border-accent text-accent hover:bg-accent/10'
            }`}
          >
            <Newspaper size={18} />
            Feed ({filteredFeed.length})
          </Button>
          {endedEvents.length > 0 && (
            <Button
              variant={activeTab === 'ended' ? 'default' : 'outline'}
              onClick={() => setActiveTab('ended')}
              className={`flex items-center gap-2 ${
                activeTab === 'ended'
                  ? 'bg-accent text-background'
                  : 'border-accent text-accent hover:bg-accent/10'
              }`}
            >
              ✓ Terminados ({endedEvents.length})
            </Button>
          )}
        </div>

        {/* Content */}
        <Card className="border-2 border-accent bg-card/50 p-4 sm:p-6">
          {activeTab === 'events' && (
            <div>
              <h2 className="text-xl sm:text-2xl font-semibold text-foreground mb-4">EVENTOS</h2>
              {eventsQuery.isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="animate-spin text-accent" />
                </div>
              ) : activeEvents.length > 0 ? (
                <div className="space-y-3">
                  {activeEvents.map(event => (
                    <div
                      key={event.id}
                      className={`p-3 border-2 rounded bg-background/50 hover:shadow-md transition-all ${getStatusClass(event.status)}`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm truncate">{event.title}</p>
                          <p className="text-xs text-muted-foreground">
                            {getStatusLabel(event.status)}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap text-xs">
                      {event.endDate && (
                        <p className="whitespace-nowrap">
                          {event.status === 'upcoming' ? 'Chega em' : 'Encerra em'} {formatDistanceToNow(new Date(event.endDate), {
                            locale: ptBR,
                            addSuffix: false,
                          })}
                          </p>
                        )}
                        {event.externalUrl && (
                          <a
                            href={event.externalUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-accent hover:text-accent/80 underline"
                          >
                            Ir →
                          </a>
                        )}
                        <ShareButton
                          title={event.title}
                          description={event.description || undefined}
                          size="sm"
                        />
                      </div>
                      {categories[event.id] && (
                        <div className="mt-2">
                          <CategoryTag category={categories[event.id] as any} size="sm" />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-sm">Nenhum evento ativo ou futuro</p>
              )}
            </div>
          )}

          {activeTab === 'ended' && (
            <div>
              <h2 className="text-xl sm:text-2xl font-semibold text-foreground mb-4">EVENTOS TERMINADOS</h2>
              {eventsQuery.isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="animate-spin text-accent" />
                </div>
              ) : endedEvents.length > 0 ? (
                <div className="space-y-3">
                  {endedEvents.map(event => (
                    <div
                      key={event.id}
                      className={`p-3 border-2 rounded bg-background/50 hover:shadow-md transition-all ${getStatusClass(event.status)}`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm truncate">{event.title}</p>
                          <p className="text-xs text-muted-foreground">Terminado</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap text-xs">
                        {event.endDate && (
                          <p className="whitespace-nowrap text-muted-foreground">
                            Terminou em {formatDistanceToNow(new Date(event.endDate), {
                              locale: ptBR,
                              addSuffix: true,
                            })}
                          </p>
                        )}
                        {event.externalUrl && (
                          <a
                            href={event.externalUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-accent hover:underline"
                          >
                            Ir →
                          </a>
                        )}
                        <ShareButton
                          title={event.title}
                          description={event.description || undefined}
                          size="sm"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-sm">Nenhum evento terminado</p>
              )}
            </div>
          )}

          {activeTab === 'drops' && (
            <div>
              <h2 className="text-xl sm:text-2xl font-semibold text-foreground mb-4">TWITCH DROPS</h2>
              {dropsQuery.isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="animate-spin text-accent" />
                </div>
              ) : filteredDrops.length > 0 ? (
                <div className="space-y-3">
                  {filteredDrops.map(drop => (
                    <div key={drop.id} className="p-3 border-2 border-accent rounded bg-background/50">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm">{drop.title}</p>
                          <p className="text-xs text-muted-foreground">{drop.rewards}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap text-xs">
                        <a
                          href={drop.watchUrl || '#'}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-accent hover:text-accent/80 underline"
                        >
                          Assistir no Twitch →
                        </a>
                        <ShareButton
                          title={drop.title}
                          description={drop.rewards ?? undefined}
                          url={drop.watchUrl ?? ''}
                          size="sm"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-sm">Nenhum drop encontrado</p>
              )}
            </div>
          )}

          {activeTab === 'feed' && (
            <div>
              <h2 className="text-xl sm:text-2xl font-semibold text-foreground mb-4">FEED DE NOTÍCIAS</h2>
              <PullToRefresh onRefresh={handleRefresh}>
                {feedQuery.isLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="animate-spin text-accent" />
                  </div>
                ) : filteredFeed.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                    {filteredFeed.map(article => (
                      <div
                        key={article.id}
                        className="group p-3 sm:p-4 border-2 border-border hover:border-accent bg-background/50 rounded transition-all duration-300 hover:shadow-lg hover:shadow-accent/20 flex flex-col"
                      >
                        {article.imageUrl && (
                          <div className="mb-3 overflow-hidden rounded aspect-video">
                            <img
                              src={article.imageUrl}
                              alt={article.title}
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                            />
                          </div>
                        )}

                        <a
                          href={article.externalUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="block flex-1"
                        >
                          <h3 className="font-semibold text-sm sm:text-base mb-2 line-clamp-2 group-hover:text-accent transition-colors duration-200">
                            {article.title}
                          </h3>
                        </a>

                        {categories[article.id] && (
                          <div className="mb-2">
                            <CategoryTag category={categories[article.id] as any} size="sm" />
                          </div>
                        )}

                        {summaries[article.id] && (
                          <p className="text-xs sm:text-sm text-muted-foreground mb-3 line-clamp-2 flex items-start gap-2">
                            <Sparkles size={12} className="text-accent flex-shrink-0 mt-0.5" />
                            <span>{summaries[article.id]}</span>
                          </p>
                        )}

                        <div className="flex items-center justify-between text-xs pt-3 border-t border-border/50 mt-auto gap-2">
                          <span className="text-accent font-medium flex-1">
                            {article.source} - {article.publishedAt ? new Date(article.publishedAt).toLocaleDateString('pt-BR') : 'Data desconhecida'}
                          </span>
                          <ShareButton
                            title={article.title}
                            description={article.description || undefined}
                            url={article.externalUrl || ''}
                            size="sm"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-sm text-center py-8">Nenhuma notícia encontrada</p>
                )}
              </PullToRefresh>
            </div>
          )}
        </Card>

        {/* Notification History */}
        <Card className="border-2 border-accent bg-card/50 p-4 sm:p-6 mt-6">
          <NotificationHistory onClearAll={() => clearBadge('events')} />
        </Card>
      </div>
    </div>
  );
}
