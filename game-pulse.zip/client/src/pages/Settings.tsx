import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Loader2, ArrowLeft, Sun, Moon } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { useEffect, useState } from 'react';
import { GameCard } from '@/components/GameCard';
import { useTheme } from '@/contexts/ThemeContext';

const GAME_ICONS: Record<string, string> = {
  'lol': '/manus-storage/lol-icon_a88fd632.png',
  'fortnite': '/manus-storage/fortnite-icon_ae51a8e2.png',
  'cs2': '/manus-storage/cs2-icon_e0c3def4.png',
  'marvel-rivals': '/manus-storage/marvel-rivals-icon_09d8365b.png',
  'darktide': '/manus-storage/darktide-icon_daa59866.png',
  'space-marine-2': '/manus-storage/space-marine-2-icon_e15d1bd3.png',
};

export default function Settings() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [selectedGames, setSelectedGames] = useState<number[]>([]);
  const { theme, toggleTheme } = useTheme();

  const gamesQuery = trpc.games.list.useQuery();
  const preferencesQuery = trpc.userPreferences.getGames.useQuery();
  const setPreferencesMutation = trpc.userPreferences.setGames.useMutation();

  useEffect(() => {
    if (preferencesQuery.data) {
      const gameIds = preferencesQuery.data.map(p => (p as any).game.id);
      setSelectedGames(gameIds);
    }
  }, [preferencesQuery.data]);

  const handleToggleGame = (gameId: number) => {
    setSelectedGames(prev =>
      prev.includes(gameId)
        ? prev.filter(id => id !== gameId)
        : [...prev, gameId]
    );
  };

  const handleSavePreferences = async () => {
    try {
      await setPreferencesMutation.mutateAsync(selectedGames);
      navigate('/dashboard');
    } catch (error) {
      console.error('Error saving preferences:', error);
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center [gap:1rem] [margin-bottom:2rem]">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/dashboard')}
            className="border-accent text-accent hover:[background-color:rgba(0,255,255,0.1)]"
          >
            <ArrowLeft size={18} className="[margin-right:0.5rem]" />
            Voltar
          </Button>
          <h1 className="[font-size:1.875rem] font-semibold text-accent neon-glow">
            CONFIGURAÇÕES
          </h1>
        </div>

        {/* Profile Card */}
        <Card className="border-2 border-accent bg-card/50 p-6 [margin-bottom:1.5rem]">
          <h2 className="text-xl font-semibold text-foreground [margin-bottom:1rem]">Perfil</h2>
          <div className="space-y-3">
            <div>
              <p className="text-xs text-muted-foreground">Nome</p>
              <p className="text-lg font-semibold text-foreground">{user?.name || 'Sem nome'}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Email</p>
              <p className="text-lg font-semibold text-foreground">{user?.email || 'Sem email'}</p>
            </div>
          </div>
        </Card>

        {/* Theme Card */}
        <Card className="border-2 border-accent bg-card/50 p-6 [margin-bottom:1.5rem]">
          <h2 className="text-xl font-semibold text-foreground [margin-bottom:1rem]">Aparência</h2>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {theme === 'dark' ? (
                <Moon className="text-accent" size={24} />
              ) : (
                <Sun className="text-accent" size={24} />
              )}
              <div>
                <p className="text-sm font-semibold text-foreground">
                  {theme === 'dark' ? 'Modo Escuro' : 'Modo Claro'}
                </p>
                <p className="text-xs text-muted-foreground">
                  Toque para alternar o tema
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={toggleTheme}
              className="border-accent text-accent hover:[background-color:rgba(0,255,255,0.1)]"
            >
              Alternar
            </Button>
          </div>
        </Card>

        {/* Games Preferences Card */}
        <Card className="border-2 border-accent bg-card/50 p-6 [margin-bottom:1.5rem]">
          <h2 className="text-xl font-semibold text-foreground [margin-bottom:1.5rem]">
            Jogos Favoritos
          </h2>

          {gamesQuery.isLoading ? (
            <div className="flex justify-center [padding-top:2rem][padding-bottom:2rem]">
              <Loader2 className="animate-spin text-accent" />
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 [gap:1rem] [margin-bottom:1.5rem]">
                {gamesQuery.data?.map(game => (
                  <GameCard
                    key={game.id}
                    game={game}
                    selected={selectedGames.includes(game.id)}
                    onClick={() => handleToggleGame(game.id)}
                    icon={GAME_ICONS[game.slug]}
                  />
                ))}
              </div>

              <Button
                size="lg"
                className="w-full bg-accent text-accent-foreground hover:bg-accent/90 border-2 border-accent"
                onClick={handleSavePreferences}
                disabled={setPreferencesMutation.isPending || selectedGames.length === 0}
              >
                {setPreferencesMutation.isPending ? (
                  <>
                    <Loader2 className="animate-spin [margin-right:0.5rem]" size={18} />
                    Salvando...
                  </>
                ) : (
                  'Salvar Preferências'
                )}
              </Button>
            </>
          )}
        </Card>

        {/* Danger Zone */}
        <Card className="border-2 border-destructive bg-card/50 p-6 [margin-bottom:1.5rem]">
          <h2 className="text-xl font-semibold text-destructive [margin-bottom:1rem]">Zona de Perigo</h2>
          <p className="text-muted-foreground [margin-bottom:1rem]">
            Fazer logout da sua conta GamePulse.
          </p>
          <Button
            variant="outline"
            className="border-destructive text-destructive hover:[background-color:rgba(255,0,255,0.1)]"
            onClick={handleLogout}
          >
            Fazer Logout
          </Button>
        </Card>
      </div>
    </div>
  );
}
