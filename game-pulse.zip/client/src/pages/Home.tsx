import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Loader2, Zap } from 'lucide-react';
import { startLogin } from '@/const';
import { useEffect, useState } from 'react';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { GameCard } from '@/components/GameCard';

const GAME_ICONS: Record<string, string> = {
  'lol': '/manus-storage/lol-icon_a88fd632.png',
  'fortnite': '/manus-storage/fortnite-icon_ae51a8e2.png',
  'cs2': '/manus-storage/cs2-icon_e0c3def4.png',
  'marvel-rivals': '/manus-storage/marvel-rivals-icon_09d8365b.png',
  'darktide': '/manus-storage/darktide-icon_daa59866.png',
  'space-marine-2': '/manus-storage/space-marine-2-icon_e15d1bd3.png',
};

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [location, navigate] = useLocation();
  const [selectedGames, setSelectedGames] = useState<number[]>([]);

  const gamesQuery = trpc.games.list.useQuery();
  const preferencesQuery = trpc.userPreferences.getGames.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const setPreferencesMutation = trpc.userPreferences.setGames.useMutation();

  useEffect(() => {
    if (preferencesQuery.data) {
      const gameIds = preferencesQuery.data.map(p => (p as any).game.id);
      setSelectedGames(gameIds);
    }
  }, [preferencesQuery.data]);

  const handleToggleGame = (gameId: number) => {
    setSelectedGames(prev =>
      prev.includes(gameId)
        ? prev.filter(id => id !== gameId)
        : [...prev, gameId]
    );
  };

  const handleSavePreferences = async () => {
    try {
      await setPreferencesMutation.mutateAsync(selectedGames);
      navigate('/dashboard');
    } catch (error) {
      console.error('Error saving preferences:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center [gap:1rem]">
          <Loader2 className="animate-spin text-accent" size={48} />
          <p className="text-foreground">Inicializando GamePulse...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center [padding-left:1rem][padding-right:1rem]">
        <div className="max-w-2xl w-full">
          <div className="text-center mb-12">
            <h1 className="text-5xl font-semibold [margin-bottom:1rem] text-accent neon-glow">
              GAMEPULSE
            </h1>
            <p className="text-xl text-muted-foreground [margin-bottom:0.5rem]">
              Monitore eventos, drops e notícias dos seus jogos favoritos
            </p>
            <p className="text-sm text-muted-foreground">
              Estética retro-futurista • Atualizações em tempo real • Twitch Drops
            </p>
          </div>

          <Card className="p-8 border-2 border-accent bg-card/50">
            <div className="space-y-6">
              <div>
                <h2 className="[font-size:1.5rem] font-semibold [margin-bottom:1rem] text-foreground">
                  Bem-vindo ao GamePulse
                </h2>
                <p className="text-muted-foreground [margin-bottom:1.5rem]">
                  Faça login para começar a acompanhar seus jogos favoritos. Você poderá:
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-center [gap:0.5rem]">
                    <Zap size={16} className="text-accent" />
                    Selecionar seus jogos favoritos
                  </li>
                  <li className="flex items-center [gap:0.5rem]">
                    <Zap size={16} className="text-accent" />
                    Ver eventos ativos e próximos
                  </li>
                  <li className="flex items-center [gap:0.5rem]">
                    <Zap size={16} className="text-accent" />
                    Acompanhar Twitch Drops
                  </li>
                  <li className="flex items-center [gap:0.5rem]">
                    <Zap size={16} className="text-accent" />
                    Receber feed de notícias agregado
                  </li>
                </ul>
              </div>

              <Button
                size="lg"
                className="w-full bg-accent text-accent-foreground hover:bg-accent/90 border-2 border-accent"
                onClick={() => startLogin()}
              >
                Fazer Login com Manus
              </Button>
            </div>
          </Card>

          <div className="mt-12 text-center text-xs text-muted-foreground">
            <p>Jogos suportados: League of Legends • Fortnite • CS2 • Marvel Rivals • Warhammer Darktide • Space Marine 2</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="[margin-bottom:2rem]">
          <h1 className="[font-size:2.25rem] font-semibold text-accent neon-glow [margin-bottom:0.5rem]">
            GAMEPULSE
          </h1>
          <p className="text-muted-foreground">
            Bem-vindo, {user?.name || 'Jogador'}! Selecione seus jogos favoritos.
          </p>
        </div>

        <Card className="p-8 border-2 border-accent bg-card/50">
          <h2 className="[font-size:1.5rem] font-semibold [margin-bottom:1.5rem] text-foreground">
            Selecione seus Jogos Favoritos
          </h2>

          {gamesQuery.isLoading ? (
            <div className="flex items-center justify-center [padding-top:2rem][padding-bottom:2rem]">
              <Loader2 className="animate-spin text-accent" />
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 [gap:1rem] [margin-bottom:2rem]">
                {gamesQuery.data?.map(game => (
                  <GameCard
                    key={game.id}
                    game={game}
                    selected={selectedGames.includes(game.id)}
                    onClick={() => handleToggleGame(game.id)}
                    icon={GAME_ICONS[game.slug]}
                  />
                ))}
              </div>

              <div className="flex [gap:1rem]">
                <Button
                  size="lg"
                  className="flex-1 bg-accent text-accent-foreground hover:bg-accent/90 border-2 border-accent"
                  onClick={handleSavePreferences}
                  disabled={setPreferencesMutation.isPending || selectedGames.length === 0}
                >
                  {setPreferencesMutation.isPending ? (
                    <>
                      <Loader2 className="animate-spin [margin-right:0.5rem]" size={18} />
                      Salvando...
                    </>
                  ) : (
                    'Continuar para Dashboard'
                  )}
                </Button>
              </div>
            </>
          )}
        </Card>
      </div>
    </div>
  );
}
