import { useEffect, useState, useMemo } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Heart, Newspaper, Calendar } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { ShareButton } from '@/components/ShareButton';
import { CategoryTag } from '@/components/CategoryTag';
import { SaveButton } from '@/components/SaveButton';
import { ThemeToggle } from '@/components/ThemeToggle';
import { Sparkles } from 'lucide-react';

export default function Favorites() {
  const [, navigate] = useLocation();
  const [savedArticles, setSavedArticles] = useState<Record<number, any>>({});
  const [savedEvents, setSavedEvents] = useState<Record<number, any>>({});
  const [activeTab, setActiveTab] = useState<'articles' | 'events'>('articles');
  const [searchQuery, setSearchQuery] = useState('');
  const [summaries, setSummaries] = useState<Record<number, string>>({});
  const [categories, setCategories] = useState<Record<number, string>>({});

  const feedQuery = trpc.dashboard.getFeed.useQuery({ limit: 100 });
  const eventsQuery = trpc.dashboard.getEvents.useQuery();
  const summarizeMutation = trpc.ai.summarizeArticle.useMutation();
  const categorizeMutation = trpc.ai.categorizeContent.useMutation();

  useEffect(() => {
    const saved = localStorage.getItem('savedArticles');
    if (saved) {
      try {
        setSavedArticles(JSON.parse(saved));
      } catch (e) {
        console.error('Error parsing saved articles:', e);
      }
    }

    const savedEvts = localStorage.getItem('savedEvents');
    if (savedEvts) {
      try {
        setSavedEvents(JSON.parse(savedEvts));
      } catch (e) {
        console.error('Error parsing saved events:', e);
      }
    }
  }, []);

  const filteredArticles = useMemo(() => {
    if (!feedQuery.data) return [];
      return feedQuery.data
        .filter(a => savedArticles[a.id])
        .filter(a =>
          a.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (a.source?.toLowerCase() || '').includes(searchQuery.toLowerCase())
        );
  }, [feedQuery.data, savedArticles, searchQuery]);

  const filteredEvents = useMemo(() => {
    if (!eventsQuery.data) return [];
    return eventsQuery.data
      .filter(e => savedEvents[e.id])
      .filter(e =>
        e.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
  }, [eventsQuery.data, savedEvents, searchQuery]);

  const generateSummary = async (id: number, title: string, description?: string) => {
    if (summaries[id]) return;
    try {
      const result = await summarizeMutation.mutateAsync({
        title,
        description,
      });
      setSummaries(prev => ({
        ...prev,
        [id]: result.summary,
      }));
    } catch (error) {
      console.error('Error generating summary:', error);
    }
  };

  const generateCategory = async (id: number, title: string, description?: string) => {
    if (categories[id]) return;
    try {
      const result = await categorizeMutation.mutateAsync({
        title,
        description,
      });
      setCategories(prev => ({
        ...prev,
        [id]: result.category,
      }));
    } catch (error) {
      console.error('Error categorizing content:', error);
    }
  };

  const handleSaveChange = (id: number, isSaved: boolean) => {
    if (activeTab === 'articles') {
      setSavedArticles(prev => {
        const updated = { ...prev };
        if (isSaved) {
          delete updated[id];
        }
        return updated;
      });
    } else {
      setSavedEvents(prev => {
        const updated = { ...prev };
        if (isSaved) {
          delete updated[id];
        }
        return updated;
      });
    }
  };

  return (
    <div className="min-h-screen bg-background px-4 py-6 sm:px-6 lg:px-8 pb-24 md:pb-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl sm:text-4xl font-semibold text-accent neon-glow mb-2">
              FAVORITOS
            </h1>
            <p className="text-sm sm:text-base text-muted-foreground">
              Seus itens salvos para leitura rápida
            </p>
          </div>
          <div className="flex gap-2">
            <ThemeToggle />
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/dashboard')}
              className="border-accent text-accent hover:bg-accent/10"
            >
              Voltar
            </Button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="mb-6">
          <input
            type="text"
            placeholder="Buscar nos favoritos..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-2 bg-background border-2 border-accent rounded text-foreground placeholder-muted-foreground focus:outline-none focus:border-accent/80"
          />
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          <Button
            variant={activeTab === 'articles' ? 'default' : 'outline'}
            onClick={() => setActiveTab('articles')}
            className={`flex items-center gap-2 ${
              activeTab === 'articles'
                ? 'bg-accent text-background'
                : 'border-accent text-accent hover:bg-accent/10'
            }`}
          >
            <Newspaper size={18} />
            Notícias ({filteredArticles.length})
          </Button>
          <Button
            variant={activeTab === 'events' ? 'default' : 'outline'}
            onClick={() => setActiveTab('events')}
            className={`flex items-center gap-2 ${
              activeTab === 'events'
                ? 'bg-accent text-background'
                : 'border-accent text-accent hover:bg-accent/10'
            }`}
          >
            <Calendar size={18} />
            Eventos ({filteredEvents.length})
          </Button>
        </div>

        {/* Content */}
        {activeTab === 'articles' ? (
          <div>
            {feedQuery.isLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="animate-spin text-accent" size={32} />
              </div>
            ) : filteredArticles.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredArticles.map(article => (
                  <div
                    key={article.id}
                    className="group p-4 border-2 border-border hover:border-accent bg-background/50 rounded transition-all duration-300 hover:shadow-lg hover:shadow-accent/20 flex flex-col"
                  >
                    {article.imageUrl && (
                      <div className="mb-3 overflow-hidden rounded aspect-video">
                        <img
                          src={article.imageUrl}
                          alt={article.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                      </div>
                    )}

                    <a
                      href={article.externalUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block flex-1"
                    >
                      <h3 className="font-semibold text-sm sm:text-base mb-2 line-clamp-2 group-hover:text-accent transition-colors duration-200">
                        {article.title}
                      </h3>
                    </a>

                    {categories[article.id] && (
                      <div className="mb-2">
                        <CategoryTag category={categories[article.id] as any} size="sm" />
                      </div>
                    )}

                    {summaries[article.id] ? (
                      <p className="text-xs sm:text-sm text-muted-foreground mb-3 line-clamp-2 flex items-start gap-2">
                        <Sparkles size={12} className="text-accent flex-shrink-0 mt-0.5" />
                        <span>{summaries[article.id]}</span>
                      </p>
                    ) : (
                      <button
                        onClick={() => generateSummary(article.id, article.title, article.description || undefined)}
                        className="text-xs sm:text-sm text-accent hover:text-accent/80 mb-3 flex items-center gap-1 transition-colors"
                        disabled={summarizeMutation.isPending}
                      >
                        <Sparkles size={12} />
                        {summarizeMutation.isPending ? 'Gerando...' : 'Resumo'}
                      </button>
                    )}

                    {!categories[article.id] && (
                      <button
                        onClick={() => generateCategory(article.id, article.title, article.description || undefined)}
                        className="text-xs sm:text-sm text-muted-foreground hover:text-accent mb-3 block transition-colors"
                        disabled={categorizeMutation.isPending}
                      >
                        {categorizeMutation.isPending ? 'Categorizando...' : 'Categorizar'}
                      </button>
                    )}

                    <div className="flex items-center justify-between text-xs pt-3 border-t border-border/50 mt-auto gap-2">
                      <span className="text-accent font-medium flex-1">
                        {article.source} - {article.publishedAt ? new Date(article.publishedAt).toLocaleDateString('pt-BR') : 'Data desconhecida'}
                      </span>
                      <div className="flex gap-1">
                        <SaveButton
                          itemId={article.id}
                          title={article.title}
                          onSaveChange={() => handleSaveChange(article.id, !!savedArticles[article.id])}
                          size="sm"
                        />
                        <ShareButton
                          title={article.title}
                          description={article.description || undefined}
                          url={article.externalUrl || ''}
                          size="sm"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <Card className="border-2 border-accent bg-card/50 p-8 text-center">
                <Heart className="mx-auto mb-4 text-muted-foreground" size={32} />
                <p className="text-muted-foreground">Nenhuma notícia salva</p>
              </Card>
            )}
          </div>
        ) : (
          <div>
            {eventsQuery.isLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="animate-spin text-accent" size={32} />
              </div>
            ) : filteredEvents.length > 0 ? (
              <div className="space-y-3">
                {filteredEvents.map(event => (
                  <Card
                    key={event.id}
                    className="border-2 border-accent bg-card/50 p-4 hover:shadow-lg hover:shadow-accent/20 transition-all"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-base mb-1">{event.title}</h3>
                        <p className="text-sm text-muted-foreground mb-2">{event.description}</p>
                        <div className="flex items-center gap-2 flex-wrap text-xs">
                          {event.endDate && (
                            <span className="text-accent">
                              Encerra em {event.endDate ? new Date(event.endDate).toLocaleDateString('pt-BR') : 'Data desconhecida'}
                            </span>
                          )}
                          {event.externalUrl && (
                            <a
                              href={event.externalUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-accent hover:text-accent/80 underline"
                            >
                              Ir para evento →
                            </a>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-1 flex-shrink-0">
                        <SaveButton
                          itemId={event.id}
                          title={event.title}
                          onSaveChange={() => handleSaveChange(event.id, !!savedEvents[event.id])}
                          size="sm"
                        />
                        <ShareButton
                          title={event.title}
                          description={event.description || undefined}
                          size="sm"
                        />
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="border-2 border-accent bg-card/50 p-8 text-center">
                <Heart className="mx-auto mb-4 text-muted-foreground" size={32} />
                <p className="text-muted-foreground">Nenhum evento salvo</p>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
