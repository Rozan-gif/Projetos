import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Loader2, ArrowLeft, Newspaper, ChevronLeft, ChevronRight } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { useState, useMemo, useEffect } from 'react';
import { formatDistanceToNow, subMonths, isAfter, isBefore } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { GameFilter } from '@/components/GameFilter';
import { CategoryTag } from '@/components/CategoryTag';
import { ShareButton } from '@/components/ShareButton';
import { SearchBar } from '@/components/SearchBar';
import { ThemeToggle } from '@/components/ThemeToggle';
import { SaveButton, getSavedItems } from '@/components/SaveButton';
import { PullToRefresh } from '@/components/PullToRefresh';

type NewsType = 'all' | 'past' | 'future' | 'saved';
const ITEMS_PER_PAGE = 10;

export default function News() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [selectedGameIds, setSelectedGameIds] = useState<number[]>([]);
  const [newsType, setNewsType] = useState<NewsType>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [savedCount, setSavedCount] = useState(0);
  const [refreshSaved, setRefreshSaved] = useState(0);

  const handleRefresh = async () => {
    try {
      await feedQuery.refetch();
      await eventsQuery.refetch();
    } catch (error) {
      console.error('Error refreshing:', error);
    }
  };

  const feedQuery = trpc.dashboard.getFeed.useQuery({ limit: 100 });
  const eventsQuery = trpc.dashboard.getEvents.useQuery();
  const gamesQuery = trpc.games.list.useQuery();

  // Update saved count on mount and when refreshSaved changes
  useEffect(() => {
    const saved = getSavedItems();
    setSavedCount(saved.length);
  }, [refreshSaved]);

  // Calculate date range (last 2 months)
  const twoMonthsAgo = subMonths(new Date(), 2);
  const now = new Date();

  // Combine and filter news and events
  const allNews = useMemo(() => {
    const news: Array<{
      id: number;
      type: 'news' | 'event';
      title: string;
      description?: string;
      date: Date;
      gameId: number;
      source?: string;
      externalUrl?: string;
      category?: string;
      isPast: boolean;
    }> = [];

    // Add feed articles
    if (feedQuery.data) {
      feedQuery.data.forEach(article => {
        const publishDate = article.publishedAt ? new Date(article.publishedAt) : new Date();
        if (isAfter(publishDate, twoMonthsAgo)) {
          news.push({
            id: article.id,
            type: 'news',
            title: article.title,
            description: article.description || undefined,
            date: publishDate,
            gameId: article.gameId,
            source: article.source || undefined,
            externalUrl: article.externalUrl || undefined,
            isPast: isBefore(publishDate, now),
          });
        }
      });
    }

    // Add events
    if (eventsQuery.data) {
      eventsQuery.data.forEach(event => {
        const eventDate = event.startDate ? new Date(event.startDate) : new Date();
        if (isAfter(eventDate, twoMonthsAgo)) {
          news.push({
            id: event.id + 10000,
            type: 'event',
            title: event.title,
            description: event.description || undefined,
            date: eventDate,
            gameId: event.gameId,
            isPast: isBefore(eventDate, now),
          });
        }
      });
    }

    // Sort by date (newest first)
    return news.sort((a, b) => b.date.getTime() - a.date.getTime());
  }, [feedQuery.data, eventsQuery.data]);

  // Filter by game
  const filteredByGame = useMemo(() => {
    if (selectedGameIds.length === 0) return allNews;
    return allNews.filter(item => selectedGameIds.includes(item.gameId));
  }, [allNews, selectedGameIds]);

  // Filter by type (past/future)
  const filteredByType = useMemo(() => {
    switch (newsType) {
      case 'past':
        return filteredByGame.filter(item => item.isPast);
      case 'future':
        return filteredByGame.filter(item => !item.isPast);
      default:
        return filteredByGame;
    }
  }, [filteredByGame, newsType]);

  // Filter by search query
  const filteredBySearch = useMemo(() => {
    if (!searchQuery.trim()) return filteredByType;
    const query = searchQuery.toLowerCase();
    return filteredByType.filter(item =>
      item.title.toLowerCase().includes(query) ||
      (item.description && item.description.toLowerCase().includes(query)) ||
      (item.source && item.source.toLowerCase().includes(query))
    );
  }, [filteredByType, searchQuery]);

  // Filter saved items
  const savedItemIds = useMemo(() => {
    const saved = getSavedItems();
    setSavedCount(saved.length);
    return saved.map((item: any) => item.id);
  }, [refreshSaved]);

  const filteredNews = useMemo(() => {
    if (newsType === "saved") {
      return filteredBySearch.filter(item => savedItemIds.includes(item.id));
    }
    return filteredBySearch;
  }, [filteredBySearch, newsType, savedItemIds]);

  // Pagination
  const totalPages = Math.ceil(filteredNews.length / ITEMS_PER_PAGE);
  const paginatedNews = useMemo(() => {
    const startIdx = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredNews.slice(startIdx, startIdx + ITEMS_PER_PAGE);
  }, [filteredNews, currentPage]);

  // Reset to page 1 when search or filters change
  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setCurrentPage(1);
  };

  const handleFilterChange = (gameIds: number[]) => {
    setSelectedGameIds(gameIds);
    setCurrentPage(1);
  };

  const handleNewsTypeChange = (type: NewsType) => {
    setNewsType(type);
    setCurrentPage(1);
  };

  const handleSaveChange = () => {
    setRefreshSaved(prev => prev + 1);
  };

  const getGameName = (gameId: number) => {
    return gamesQuery.data?.find(g => g.id === gameId)?.name || 'Jogo desconhecido';
  };

  return (
    <div className="min-h-screen bg-background [padding-left:1rem][padding-right:1rem][padding-top:2rem][padding-bottom:2rem]">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between [gap:1rem] [margin-bottom:2rem]">
          <div className="flex items-center [gap:1rem]">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/dashboard')}
              className="border-accent text-accent hover:[background-color:rgba(0,255,255,0.1)]"
            >
              <ArrowLeft size={18} className="[margin-right:0.5rem]" />
              Voltar
            </Button>
            <h1 className="[font-size:2.25rem] font-semibold text-accent neon-glow">
              ÚLTIMAS NOTÍCIAS
            </h1>
          </div>
          <ThemeToggle />
        </div>

        {/* Search Bar */}
        <div className="[margin-bottom:2rem]">
          <SearchBar onSearch={handleSearch} />
        </div>

        {/* Filters */}
        <div className="space-y-4 [margin-bottom:2rem]">
          {gamesQuery.data && (
            <GameFilter
              games={gamesQuery.data}
              selectedGameIds={selectedGameIds}
              onFilterChange={handleFilterChange}
            />
          )}

          {/* Type Filter */}
          <div className="flex [gap:0.5rem] flex-wrap">
            <Button
              variant={newsType === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => handleNewsTypeChange('all')}
              className={
                newsType === 'all'
                  ? 'bg-accent text-accent-foreground'
                  : 'border-accent text-accent hover:[background-color:rgba(0,255,255,0.1)]'
              }
            >
              Todas
            </Button>
            <Button
              variant={newsType === 'past' ? 'default' : 'outline'}
              size="sm"
              onClick={() => handleNewsTypeChange('past')}
              className={
                newsType === 'past'
                  ? 'bg-accent text-accent-foreground'
                  : 'border-accent text-accent hover:[background-color:rgba(0,255,255,0.1)]'
              }
            >
              Últimas Atualizações
            </Button>
            <Button
              variant={newsType === 'future' ? 'default' : 'outline'}
              size="sm"
              onClick={() => handleNewsTypeChange('future')}
              className={
                newsType === 'future'
                  ? 'bg-accent text-accent-foreground'
                  : 'border-accent text-accent hover:[background-color:rgba(0,255,255,0.1)]'
              }
            >
              Próximos Anúncios
            </Button>
            <Button
              variant={newsType === 'saved' ? 'default' : 'outline'}
              size="sm"
              onClick={() => handleNewsTypeChange('saved')}
              className={
                newsType === 'saved'
                  ? 'bg-accent text-accent-foreground'
                  : 'border-accent text-accent hover:[background-color:rgba(0,255,255,0.1)]'
              }
            >
              Salvos ({savedCount})
            </Button>
          </div>
        </div>

        {/* Results info */}
        {filteredNews.length > 0 && (
          <p className="text-xs text-muted-foreground [margin-bottom:1rem]">
            Mostrando {(currentPage - 1) * ITEMS_PER_PAGE + 1}-{Math.min(currentPage * ITEMS_PER_PAGE, filteredNews.length)} de {filteredNews.length} resultados
          </p>
        )}

        {/* Timeline */}
        <Card className="border-2 border-accent bg-card/50 p-6 [margin-bottom:2rem]">
          <PullToRefresh onRefresh={handleRefresh}>
            {feedQuery.isLoading || eventsQuery.isLoading ? (
              <div className="flex justify-center [padding-top:2rem][padding-bottom:2rem]">
                <Loader2 className="animate-spin text-accent" />
              </div>
            ) : paginatedNews.length > 0 ? (
              <div className="space-y-3">
                {paginatedNews.map((item, idx) => (
                <div key={`${item.type}-${item.id}`} className="relative">
                  {/* Timeline line */}
                  {idx < paginatedNews.length - 1 && (
                    <div className="absolute left-6 top-16 w-0.5 h-12 bg-gradient-to-b from-accent to-accent/30" />
                  )}

                  {/* Timeline dot */}
                  <div className="flex [gap:1rem]">
                    <div className="flex flex-col items-center">
                      <div
                        className="w-4 h-4 rounded-full border-2 flex items-center justify-center"
                        style={{
                          borderColor: item.type === 'event' ? '#00ffff' : '#ff00ff',
                          backgroundColor: item.type === 'event' ? 'rgba(0, 255, 255, 0.2)' : 'rgba(255, 0, 255, 0.2)',
                        }}
                      >
                        <div
                          className="w-2 h-2 rounded-full"
                          style={{
                            backgroundColor: item.type === 'event' ? '#00ffff' : '#ff00ff',
                          }}
                        />
                      </div>
                    </div>

                    {/* Content */}
                    <div className="flex-1 [margin-bottom:1rem]">
                      <div className="flex items-start justify-between [gap:1rem] [margin-bottom:0.5rem]">
                        <div>
                          <h3 className="font-semibold text-lg text-foreground">{item.title}</h3>
                          <p className="text-xs text-muted-foreground">
                            {getGameName(item.gameId)} • {item.type === 'event' ? 'Evento' : 'Notícia'}
                          </p>
                        </div>
                        <div className="flex flex-col items-end [gap:0.25rem]">
                          <span className="text-xs text-accent whitespace-nowrap">
                            {item.date.toLocaleDateString('pt-BR', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric',
                            })}
                          </span>
                          <span className="text-xs text-muted-foreground whitespace-nowrap">
                            {item.date.toLocaleTimeString('pt-BR', {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>
                      </div>

                      {item.description && (
                        <p className="text-sm text-muted-foreground [margin-bottom:0.75rem]">
                          {item.description}
                        </p>
                      )}

                      <div className="flex items-center [gap:0.75rem] flex-wrap justify-between">
                        <div className="flex items-center [gap:0.75rem] flex-wrap">
                          {item.type === 'news' && item.source && (
                            <span className="text-xs bg-background/50 border border-border rounded [padding-left:0.5rem][padding-right:0.5rem][padding-top:0.25rem][padding-bottom:0.25rem]">
                              {item.source}
                            </span>
                          )}
                          {item.isPast ? (
                            <span className="text-xs text-[color:#00ffff] bg-[background-color:rgba(0,255,255,0.1)] border border-[color:#00ffff] rounded [padding-left:0.5rem][padding-right:0.5rem][padding-top:0.25rem][padding-bottom:0.25rem]">
                              Passado
                            </span>
                          ) : (
                            <span className="text-xs text-[color:#ffff00] bg-[background-color:rgba(255,255,0,0.1)] border border-[color:#ffff00] rounded [padding-left:0.5rem][padding-right:0.5rem][padding-top:0.25rem][padding-bottom:0.25rem]">
                              Futuro
                            </span>
                          )}
                          {item.externalUrl && (
                            <a
                              href={item.externalUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-xs text-accent hover:text-accent/80"
                            >
                              Ler mais →
                            </a>
                          )}
                        </div>
                        <div className="flex items-center [gap:0.5rem]">
                          <SaveButton
                            itemId={item.id}
                            title={item.title}
                            size="sm"
                            onSaveChange={handleSaveChange}
                          />
                          <ShareButton
                            title={item.title}
                            description={item.description}
                            url={item.externalUrl || ''}
                            size="sm"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              </div>
            ) : (
              <div className="text-center [padding-top:2rem][padding-bottom:2rem]">
                <Newspaper className="mx-auto [margin-bottom:1rem] text-muted-foreground" size={48} />
                <p className="text-muted-foreground">Nenhuma notícia encontrada</p>
              </div>
            )}
          </PullToRefresh>
        </Card>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center [gap:1rem]">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
              className="border-accent text-accent hover:[background-color:rgba(0,255,255,0.1)] disabled:opacity-50"
            >
              <ChevronLeft size={18} />
            </Button>
            <span className="text-sm text-muted-foreground">
              Página {currentPage} de {totalPages}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages}
              className="border-accent text-accent hover:[background-color:rgba(0,255,255,0.1)] disabled:opacity-50"
            >
              <ChevronRight size={18} />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
