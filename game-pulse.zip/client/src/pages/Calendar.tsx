import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Loader2, ChevronLeft, ChevronRight, ArrowLeft } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { useState, useMemo } from 'react';
import {
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  format,
  addMonths,
  isSameMonth,
  isToday,
} from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { GameFilter } from '@/components/GameFilter';
import { CategoryTag } from '@/components/CategoryTag';

export default function Calendar() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedGameIds, setSelectedGameIds] = useState<number[]>([]);

  const eventsQuery = trpc.dashboard.getEvents.useQuery();
  const gamesQuery = trpc.games.list.useQuery();

  // Filter events by selected games
  const filteredEvents = useMemo(() => {
    if (!eventsQuery.data) return [];
    if (selectedGameIds.length === 0) return eventsQuery.data;
    return eventsQuery.data.filter(e => selectedGameIds.includes(e.gameId));
  }, [eventsQuery.data, selectedGameIds]);

  // Get all days in the current month
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  // Group events by date
  const eventsByDate = useMemo(() => {
    const map = new Map<string, typeof filteredEvents>();
    if (!filteredEvents) return map;

    filteredEvents.forEach(event => {
      if (event.startDate) {
        const dateKey = format(new Date(event.startDate), 'yyyy-MM-dd');
        if (!map.has(dateKey)) {
          map.set(dateKey, []);
        }
        map.get(dateKey)!.push(event);
      }
    });

    return map;
  }, [filteredEvents]);

  const handlePrevMonth = () => {
    setCurrentDate(addMonths(currentDate, -1));
  };

  const handleNextMonth = () => {
    setCurrentDate(addMonths(currentDate, 1));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'text-[color:#00ffff]';
      case 'upcoming':
        return 'text-[color:#ffff00]';
      case 'ended':
        return 'text-[color:#808080]';
      default:
        return 'text-muted-foreground';
    }
  };

  const weekDays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'];
  const calendarDays = [];

  // Add padding days from previous month
  for (let i = 0; i < monthStart.getDay(); i++) {
    calendarDays.push(null);
  }

  // Add days of current month
  daysInMonth.forEach(day => {
    calendarDays.push(day);
  });

  return (
    <div className="min-h-screen bg-background [padding-left:1rem][padding-right:1rem][padding-top:2rem][padding-bottom:2rem]">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center [gap:1rem] [margin-bottom:2rem]">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/dashboard')}
            className="border-accent text-accent hover:[background-color:rgba(0,255,255,0.1)]"
          >
            <ArrowLeft size={18} className="[margin-right:0.5rem]" />
            Voltar
          </Button>
          <h1 className="[font-size:2.25rem] font-semibold text-accent neon-glow">
            CALENDÁRIO DE EVENTOS
          </h1>
        </div>

        {/* Filter Section */}
        {gamesQuery.data && (
          <div className="[margin-bottom:2rem]">
            <GameFilter
              games={gamesQuery.data}
              selectedGameIds={selectedGameIds}
              onFilterChange={setSelectedGameIds}
            />
          </div>
        )}

        {/* Calendar Card */}
        <Card className="border-2 border-accent bg-card/50 p-6">
          {/* Month Navigation */}
          <div className="flex items-center justify-between [margin-bottom:2rem]">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrevMonth}
              className="border-accent text-accent hover:[background-color:rgba(0,255,255,0.1)]"
            >
              <ChevronLeft size={18} />
            </Button>
            <h2 className="[font-size:1.875rem] font-semibold text-foreground">
              {format(currentDate, 'MMMM yyyy', { locale: ptBR })}
            </h2>
            <Button
              variant="outline"
              size="sm"
              onClick={handleNextMonth}
              className="border-accent text-accent hover:[background-color:rgba(0,255,255,0.1)]"
            >
              <ChevronRight size={18} />
            </Button>
          </div>

          {/* Calendar Grid */}
          {eventsQuery.isLoading ? (
            <div className="flex justify-center [padding-top:2rem][padding-bottom:2rem]">
              <Loader2 className="animate-spin text-accent" />
            </div>
          ) : (
            <>
              {/* Week Days Header */}
              <div className="grid grid-cols-7 [gap:0.5rem] [margin-bottom:1rem]">
                {weekDays.map(day => (
                  <div
                    key={day}
                    className="text-center font-semibold text-accent text-sm"
                  >
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar Days */}
              <div className="grid grid-cols-7 [gap:0.5rem]">
                {calendarDays.map((day, idx) => {
                  const dateKey = day ? format(day, 'yyyy-MM-dd') : null;
                  const dayEvents = dateKey ? eventsByDate.get(dateKey) : [];
                  const isCurrentMonth = day ? isSameMonth(day, currentDate) : false;
                  const isTodayDate = day ? isToday(day) : false;

                  return (
                    <div
                      key={idx}
                      className={`min-h-24 p-2 border-2 rounded transition-all ${
                        !isCurrentMonth
                          ? 'bg-background/30 border-border/30'
                          : isTodayDate
                            ? 'border-accent bg-accent/5'
                            : 'border-border bg-card/30'
                      }`}
                    >
                      {day && (
                        <>
                          <div
                            className={`text-sm font-semibold [margin-bottom:0.5rem] ${
                              isTodayDate ? 'text-accent' : 'text-foreground'
                            }`}
                          >
                            {format(day, 'd')}
                          </div>
                          {dayEvents && dayEvents.length > 0 && (
                            <div className="space-y-1">
                              {dayEvents.slice(0, 2).map(event => (
                                <div
                                  key={event.id}
                                  className={`text-xs truncate ${getStatusColor(event.status)}`}
                                  title={event.title}
                                >
                                  • {event.title}
                                </div>
                              ))}
                              {dayEvents.length > 2 && (
                                <div className="text-xs text-muted-foreground">
                                  +{dayEvents.length - 2} mais
                                </div>
                              )}
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Legend */}
              <div className="mt-8 pt-6 border-t border-border">
                <h3 className="font-semibold text-foreground [margin-bottom:1rem]">Legenda:</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 [gap:1rem]">
                  <div className="flex items-center [gap:0.5rem]">
                    <div className="w-4 h-4 border-2" style={{ borderColor: '#00ffff' }} />
                    <span className="text-sm text-muted-foreground">Ativo</span>
                  </div>
                  <div className="flex items-center [gap:0.5rem]">
                    <div className="w-4 h-4 border-2" style={{ borderColor: '#ffff00' }} />
                    <span className="text-sm text-muted-foreground">Próximo</span>
                  </div>
                  <div className="flex items-center [gap:0.5rem]">
                    <div className="w-4 h-4 border-2" style={{ borderColor: '#808080' }} />
                    <span className="text-sm text-muted-foreground">Encerrado</span>
                  </div>
                </div>
              </div>
            </>
          )}
        </Card>
      </div>
    </div>
  );
}
