import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Loader2, Calendar, Gift, Newspaper, Settings, Sparkles, AlertCircle } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useState, useMemo, useEffect } from 'react';
import { GameFilter } from '@/components/GameFilter';
import { CategoryTag } from '@/components/CategoryTag';
import { ShareButton } from '@/components/ShareButton';
import { ThemeToggle } from '@/components/ThemeToggle';
import { useAuth } from '@/_core/hooks/useAuth';
import { PullToRefresh } from '@/components/PullToRefresh';

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();

  const eventsQuery = trpc.dashboard.getEvents.useQuery();
  const dropsQuery = trpc.dashboard.getDrops.useQuery();
  const feedQuery = trpc.dashboard.getFeed.useQuery({ limit: 20 });
  const gamesQuery = trpc.games.list.useQuery();
  const summarizeMutation = trpc.ai.summarizeArticle.useMutation();
  const categorizeMutation = trpc.ai.categorizeContent.useMutation();
  
  const [summaries, setSummaries] = useState<Record<number, string>>({});
  const [categories, setCategories] = useState<Record<number, string>>({});
  const [selectedGameIds, setSelectedGameIds] = useState<number[]>([]);

  // Auto-generate categories and summaries for feed articles
  useEffect(() => {
    if (feedQuery.data && feedQuery.data.length > 0) {
      feedQuery.data.forEach(article => {
        if (!categories[article.id]) {
          generateCategory(article.id, article.title, article.description || undefined);
        }
        if (!summaries[article.id]) {
          generateSummary(article.id, article.title, article.description || undefined);
        }
      });
    }
  }, [feedQuery.data]);

  const handleRefresh = async () => {
    try {
      await feedQuery.refetch();
      await eventsQuery.refetch();
      await dropsQuery.refetch();
    } catch (error) {
      console.error('Error refreshing:', error);
    }
  };

  // Filter data based on selected games
  const filteredEvents = useMemo(() => {
    if (!eventsQuery.data) return [];
    if (selectedGameIds.length === 0) return eventsQuery.data;
    return eventsQuery.data.filter(e => selectedGameIds.includes(e.gameId));
  }, [eventsQuery.data, selectedGameIds]);

  const filteredDrops = useMemo(() => {
    if (!dropsQuery.data) return [];
    if (selectedGameIds.length === 0) return dropsQuery.data;
    return dropsQuery.data.filter(d => selectedGameIds.includes(d.gameId));
  }, [dropsQuery.data, selectedGameIds]);

  const filteredFeed = useMemo(() => {
    if (!feedQuery.data) return [];
    if (selectedGameIds.length === 0) return feedQuery.data;
    return feedQuery.data.filter(a => selectedGameIds.includes(a.gameId));
  }, [feedQuery.data, selectedGameIds]);

  const generateSummary = async (id: number, title: string, description?: string) => {
    if (summaries[id]) return;
    try {
      const result = await summarizeMutation.mutateAsync({
        title,
        description,
      });
      setSummaries(prev => ({
        ...prev,
        [id]: result.summary,
      }));
    } catch (error) {
      console.error('Error generating summary:', error);
    }
  };

  const generateCategory = async (id: number, title: string, description?: string) => {
    if (categories[id]) return;
    try {
      const result = await categorizeMutation.mutateAsync({
        title,
        description,
      });
      setCategories(prev => ({
        ...prev,
        [id]: result.category,
      }));
    } catch (error) {
      console.error('Error categorizing content:', error);
    }
  };

  const getStatusClass = (status: string) => {
    switch (status) {
      case 'active':
        return 'border-accent text-accent';
      case 'upcoming':
        return 'border-yellow-400 text-yellow-400';
      case 'completed':
        return 'border-gray-500 text-gray-500';
      default:
        return 'border-border text-foreground';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active':
        return 'EM ANDAMENTO';
      case 'upcoming':
        return 'PRÓXIMO';
      case 'completed':
        return 'ENCERRADO';
      default:
        return status;
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background px-4 py-6 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl sm:text-4xl font-semibold text-accent neon-glow mb-2">
              GAMEPULSE
            </h1>
            <p className="text-sm sm:text-base text-muted-foreground">
              Bem-vindo, {user?.name || 'Jogador'}
            </p>
          </div>
          <div className="flex flex-wrap gap-2 w-full sm:w-auto">
            <ThemeToggle />
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/calendar')}
              className="border-accent text-accent hover:bg-accent/10 flex-1 sm:flex-none"
            >
              <Calendar size={16} className="mr-2" />
              Calendário
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/news')}
              className="border-accent text-accent hover:bg-accent/10 flex-1 sm:flex-none"
            >
              <Newspaper size={16} className="mr-2" />
              Notícias
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/settings')}
              className="border-accent text-accent hover:bg-accent/10 flex-1 sm:flex-none"
            >
              <Settings size={16} className="mr-2" />
              Config
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleLogout}
              className="border-destructive text-destructive hover:bg-destructive/10 flex-1 sm:flex-none"
            >
              Sair
            </Button>
          </div>
        </div>

        {/* Filter Section */}
        {gamesQuery.data && (
          <div className="mb-8">
            <GameFilter
              games={gamesQuery.data}
              selectedGameIds={selectedGameIds}
              onFilterChange={setSelectedGameIds}
            />
          </div>
        )}

        {/* Feed Section - TOP PRIORITY */}
        <Card className="border-2 border-accent bg-card/50 p-4 sm:p-6 mb-8">
          <div className="flex items-center gap-2 sm:gap-3 mb-4 sm:mb-6">
            <Newspaper className="text-accent flex-shrink-0" size={24} />
            <h2 className="text-xl sm:text-2xl font-semibold text-foreground">FEED DE NOTÍCIAS</h2>
          </div>

          <PullToRefresh onRefresh={handleRefresh}>
            {feedQuery.isLoading ? (
              <div className="flex justify-center py-8 sm:py-12">
                <Loader2 className="animate-spin text-accent" size={32} />
              </div>
            ) : filteredFeed && filteredFeed.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
              {filteredFeed.map(article => (
                <div
                  key={article.id}
                  className="group p-3 sm:p-4 border-2 border-border hover:border-accent bg-background/50 rounded transition-all duration-300 hover:shadow-lg hover:shadow-accent/20 flex flex-col"
                >
                  {article.imageUrl && (
                    <div className="mb-3 overflow-hidden rounded aspect-video">
                      <img
                        src={article.imageUrl}
                        alt={article.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                    </div>
                  )}
                  
                  <a
                    href={article.externalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block flex-1"
                  >
                    <h3 className="font-semibold text-sm sm:text-base mb-2 line-clamp-2 group-hover:text-accent transition-colors duration-200">
                      {article.title}
                    </h3>
                  </a>
                  
                  {categories[article.id] && (
                    <div className="mb-2">
                      <CategoryTag category={categories[article.id] as any} size="sm" />
                    </div>
                  )}
                  
                  {summaries[article.id] && (
                    <p className="text-xs sm:text-sm text-muted-foreground mb-3 line-clamp-2 flex items-start gap-2">
                      <Sparkles size={12} className="text-accent flex-shrink-0 mt-0.5" />
                      <span>{summaries[article.id]}</span>
                    </p>
                  )}

                  <div className="flex items-center justify-between text-xs pt-3 border-t border-border/50 mt-auto">
                    <div className="flex-1">
                      {article.publishedAt && (
                        <span className="text-accent font-medium">
                          {article.source} - {new Date(article.publishedAt).toLocaleDateString('pt-BR', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric',
                          })}
                        </span>
                      )}
                    </div>
                    <ShareButton
                      title={article.title}
                      description={article.description || undefined}
                      url={article.externalUrl || ''}
                      size="sm"
                    />
                  </div>
                </div>
              ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm text-center py-8">Nenhuma notícia encontrada</p>
            )}
          </PullToRefresh>
        </Card>

        {/* Main Grid - Events and Drops */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-8">
          {/* Events Section */}
          <Card className="border-2 border-accent bg-card/50 p-4 sm:p-6">
            <div className="flex items-center gap-2 sm:gap-3 mb-4">
              <Calendar className="text-accent flex-shrink-0" size={24} />
              <h2 className="text-lg sm:text-xl font-semibold text-foreground">EVENTOS</h2>
            </div>

            {eventsQuery.isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="animate-spin text-accent" />
              </div>
            ) : filteredEvents && filteredEvents.length > 0 ? (
              <div className="space-y-3">
                {filteredEvents.slice(0, 5).map(event => (
                  <div
                    key={event.id}
                    className={`p-3 border-2 rounded bg-background/50 hover:shadow-md transition-all ${getStatusClass(event.status)}`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm truncate">{event.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {getStatusLabel(event.status)}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap text-xs">
                      {event.endDate && (
                        <p className="whitespace-nowrap">
                          Encerra em {formatDistanceToNow(new Date(event.endDate), {
                            locale: ptBR,
                            addSuffix: false,
                          })}
                        </p>
                      )}
                      {event.externalUrl && (
                        <a
                          href={event.externalUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-accent hover:text-accent/80 underline"
                        >
                          Ir →
                        </a>
                      )}
                      <ShareButton
                        title={event.title}
                        description={event.description || undefined}
                        size="sm"
                      />
                    </div>
                    {categories[event.id] && (
                      <CategoryTag category={categories[event.id] as any} size="sm" />
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm">Nenhum evento encontrado</p>
            )}
          </Card>

          {/* Twitch Drops Section */}
          <Card className="border-2 border-accent bg-card/50 p-4 sm:p-6">
            <div className="flex items-center gap-2 sm:gap-3 mb-4">
              <Gift className="text-accent flex-shrink-0" size={24} />
              <h2 className="text-lg sm:text-xl font-semibold text-foreground">DROPS</h2>
            </div>

            {dropsQuery.isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="animate-spin text-accent" />
              </div>
            ) : filteredDrops && filteredDrops.length > 0 ? (
              <div className="space-y-3">
                {filteredDrops.slice(0, 5).map(drop => (
                  <div
                    key={drop.id}
                    className="p-3 border-2 border-accent/50 hover:border-accent bg-background/50 rounded transition-all"
                  >
                    <p className="font-semibold text-sm mb-1">{drop.title}</p>
                    <p className="text-xs text-muted-foreground mb-2">{drop.rewards}</p>
                    {drop.watchUrl && (
                      <a
                        href={drop.watchUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-accent hover:text-accent/80 inline-flex items-center gap-1"
                      >
                        Assistir no Twitch →
                      </a>
                    )}
                    <ShareButton
                      title={drop.title}
                      description={drop.rewards || undefined}
                      size="sm"
                    />
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm">Nenhum drop ativo</p>
            )}
          </Card>

          {/* Stats Section */}
          <Card className="border-2 border-accent bg-card/50 p-4 sm:p-6">
            <h2 className="text-lg sm:text-xl font-semibold text-foreground mb-4">ESTATÍSTICAS</h2>
            <div className="space-y-3">
              <div className="p-3 bg-background/50 border border-border rounded hover:border-accent transition-colors">
                <p className="text-xs text-muted-foreground mb-1">Eventos Ativos</p>
                <p className="text-2xl sm:text-3xl font-semibold text-accent">
                  {filteredEvents?.filter(e => e.status === 'active').length || 0}
                </p>
              </div>
              <div className="p-3 bg-background/50 border border-border rounded hover:border-accent transition-colors">
                <p className="text-xs text-muted-foreground mb-1">Drops Disponíveis</p>
                <p className="text-2xl sm:text-3xl font-semibold text-accent">
                  {filteredDrops?.filter(d => d.status === 'active').length || 0}
                </p>
              </div>
              <div className="p-3 bg-background/50 border border-border rounded hover:border-accent transition-colors">
                <p className="text-xs text-muted-foreground mb-1">Notícias Recentes</p>
                <p className="text-2xl sm:text-3xl font-semibold text-accent">
                  {filteredFeed?.length || 0}
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
