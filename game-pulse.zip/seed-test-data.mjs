import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import { gameEvents, feedArticles, twitchDrops } from './drizzle/schema.ts';

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'game_pulse',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

const db = drizzle(pool);

async function seedData() {
  try {
    console.log('Inserindo dados de teste...');

    // Inserir eventos
    await db.insert(gameEvents).values([
      {
        gameId: 1,
        title: 'Campeonato Regional LoL 2026',
        description: 'Torneio regional com os melhores times',
        startDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
        endDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000),
        status: 'upcoming',
      },
      {
        gameId: 1,
        title: 'Patch 14.5 - Novos Campeões',
        description: 'Atualização com novos campeões e balanceamento',
        startDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
        endDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
        status: 'upcoming',
      },
      {
        gameId: 2,
        title: 'Fortnite Festival - Semana 3',
        description: 'Novos desafios e recompensas exclusivas',
        startDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
        endDate: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000),
        status: 'active',
      },
      {
        gameId: 3,
        title: 'CS2 Major Championship',
        description: 'Campeonato mundial de CS2',
        startDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000),
        endDate: new Date(Date.now() + 20 * 24 * 60 * 60 * 1000),
        status: 'upcoming',
      },
    ]);
    console.log('✓ Eventos inseridos');

    // Inserir artigos
    await db.insert(feedArticles).values([
      {
        gameId: 1,
        title: 'Novo campeão anunciado para League of Legends',
        description: 'Riot Games anuncia um novo campeão que chegará no próximo patch',
        content: 'Um novo campeão mágico chegará em breve ao Rift',
        source: 'Riot News',
        externalUrl: 'https://news.leagueoflegends.com',
        publishedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      },
      {
        gameId: 1,
        title: 'Mudanças no sistema de rank 2026',
        description: 'Alterações significativas no sistema de classificação',
        content: 'O sistema de rank sofrerá mudanças importantes',
        source: 'Riot News',
        externalUrl: 'https://news.leagueoflegends.com',
        publishedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      },
      {
        gameId: 2,
        title: 'Fortnite Season 6 - Novos locais',
        description: 'Explorar novos locais no mapa de Fortnite',
        content: 'A Season 6 traz novos pontos de interesse',
        source: 'Fortnite Blog',
        externalUrl: 'https://www.fortnite.com/news',
        publishedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      },
      {
        gameId: 3,
        title: 'CS2 recebe novo mapa competitivo',
        description: 'Valve lança novo mapa para competições',
        content: 'Um novo mapa foi adicionado à rotação competitiva',
        source: 'CS2 News',
        externalUrl: 'https://www.counter-strike.net',
        publishedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
      },
      {
        gameId: 4,
        title: 'Marvel Rivals - Novo herói: Homem-Aranha',
        description: 'Homem-Aranha se junta ao elenco de heróis',
        content: 'O Homem-Aranha é o novo herói jogável',
        source: 'Marvel Rivals',
        externalUrl: 'https://www.marvelrivals.com/news',
        publishedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      },
    ]);
    console.log('✓ Artigos inseridos');

    // Inserir drops
    await db.insert(twitchDrops).values([
      {
        gameId: 1,
        title: 'LoL World Championship Drops',
        description: 'Ganhe skins exclusivas assistindo',
        rewardName: 'Skin Exclusiva Worlds 2026',
        campaignStart: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        campaignEnd: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000),
        status: 'active',
        watchUrl: 'https://www.twitch.tv/directory/game/League%20of%20Legends',
      },
      {
        gameId: 2,
        title: 'Fortnite Festival Drops',
        description: 'Recompensas exclusivas do Festival',
        rewardName: 'Emote Raro Festival',
        campaignStart: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        campaignEnd: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        status: 'active',
        watchUrl: 'https://www.twitch.tv/directory/game/Fortnite',
      },
      {
        gameId: 3,
        title: 'CS2 Major Drops',
        description: 'Itens exclusivos do Major',
        rewardName: 'Agente Exclusivo Major',
        campaignStart: new Date(Date.now() + 8 * 24 * 60 * 60 * 1000),
        campaignEnd: new Date(Date.now() + 18 * 24 * 60 * 60 * 1000),
        status: 'upcoming',
        watchUrl: 'https://www.twitch.tv/directory/game/Counter-Strike%202',
      },
    ]);
    console.log('✓ Drops inseridos');

    console.log('\n✅ Dados de teste inseridos com sucesso!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Erro ao inserir dados:', error.message);
    process.exit(1);
  }
}

seedData();
