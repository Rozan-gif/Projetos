# GamePulse - Deploy no Netlify

## Opções de Download

### Opção 1: Download via Management UI (Recomendado)
1. Acesse o Management UI do GamePulse
2. Clique no menu "⋯" (três pontos)
3. Selecione "Download as ZIP"
4. Extraia o arquivo

### Opção 2: Clone via GitHub
```bash
gh repo clone seu-usuario/game-pulse
cd game-pulse
pnpm install
```

## Estrutura do Projeto

```
game-pulse/
├── client/              # Frontend React
├── server/              # Backend Express + tRPC
├── drizzle/             # Schema e migrations do banco
├── netlify.toml         # Configuração Netlify
├── DEPLOY_NETLIFY.md    # Guia completo de deploy
└── package.json         # Dependências
```

## Quick Start para Netlify

1. **Faça upload para GitHub**
   ```bash
   git init
   git add .
   git commit -m "GamePulse v1.24"
   git push origin main
   ```

2. **Conecte no Netlify**
   - Vá para https://app.netlify.com
   - Clique "Import from Git"
   - Selecione seu repositório

3. **Configure variáveis de ambiente**
   - Veja `DEPLOY_NETLIFY.md` para lista completa
   - Adicione em Netlify: Site settings → Build & deploy → Environment

4. **Deploy automático**
   - Netlify detectará changes no GitHub
   - Build e deploy acontecem automaticamente

## Banco de Dados

Você precisa de um banco MySQL/TiDB. Opções:

- **Planetscale** (grátis): https://planetscale.com
- **AWS RDS**: https://aws.amazon.com/rds/
- **Supabase** (com PostgreSQL): https://supabase.com
- **Seu próprio servidor**: MySQL 8.0+

Após criar o banco, atualize `DATABASE_URL` nas variáveis de ambiente.

## Arquivos Importantes

- `netlify.toml` - Configuração de build
- `DEPLOY_NETLIFY.md` - Guia detalhado
- `drizzle/schema.ts` - Schema do banco
- `package.json` - Dependências

## Suporte

Para problemas de deploy, verifique:
1. Todas as variáveis de ambiente estão configuradas?
2. Banco de dados está acessível?
3. Node.js 18+ está instalado?
4. pnpm está disponível?

