import mysql from 'mysql2/promise';

async function fixFortniteData() {
  const dbUrl = process.env.DATABASE_URL;
  
  // Parse DATABASE_URL: mysql://user:pass@host:port/database?ssl=...
  const urlParts = dbUrl.match(/mysql:\/\/([^:]+):([^@]+)@([^:]+):(\d+)\/([^?]+)/);
  
  if (!urlParts) {
    console.error('❌ DATABASE_URL format inválido');
    return;
  }

  const [, user, password, host, port, database] = urlParts;

  const connection = await mysql.createConnection({
    host,
    user,
    password,
    database,
    port: parseInt(port),
    ssl: { rejectUnauthorized: false },
  });

  try {
    // Delete old Fortnite articles
    await connection.execute(
      'DELETE FROM `feed_articles` WHERE gameId = 2'
    );

    // Insert new Fortnite Season 15 articles
    const articles = [
      ['Fortnite Chapter 7 Season 15: Runners - Temporada Oficial', 'A temporada 15 do Fortnite traz novos heróis, armas e modos de jogo emocionantes com a temática Runners', 'https://www.fortnite.com/news', 'Epic Games', '2026-06-06'],
      ['Festival Season 15 com Lil Tecca', 'Novo evento Festival na temporada 15 com artista Lil Tecca e músicas exclusivas', 'https://www.fortnite.com/news', 'Epic Games', '2026-06-10'],
      ['Novos Heróis e Skins da Temporada 15', 'Conheça os novos heróis e skins exclusivas disponíveis na Battle Pass da temporada 15', 'https://www.fortnite.com/news', 'Epic Games', '2026-06-15'],
      ['Patch 26.10 - Balanceamento de Armas', 'Novo patch com balanceamento de armas e correção de bugs na temporada 15', 'https://www.fortnite.com/news', 'Epic Games', '2026-07-20'],
      ['Fortnite Esports - FNCS Season 15', 'Torneio FNCS da temporada 15 com prêmios de milhões de dólares', 'https://www.fortnite.com/news', 'Epic Games', '2026-07-25'],
    ];

    for (const [title, description, externalUrl, source, publishedAt] of articles) {
      await connection.execute(
        'INSERT INTO `feed_articles` (gameId, title, description, externalUrl, source, publishedAt) VALUES (?, ?, ?, ?, ?, ?)',
        [2, title, description, externalUrl, source, publishedAt]
      );
    }

    console.log('✅ Dados do Fortnite atualizados para temporada 15!');
  } catch (error) {
    console.error('❌ Erro ao atualizar dados:', error.message);
  } finally {
    await connection.end();
  }
}

fixFortniteData();
