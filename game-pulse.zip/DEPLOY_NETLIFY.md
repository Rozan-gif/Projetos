# Guia de Deploy - GamePulse no Netlify

## Pré-requisitos

1. Conta no Netlify (https://netlify.com)
2. Conta no GitHub (para conectar o repositório)
3. Banco de dados MySQL/TiDB (recomendado: Planetscale, AWS RDS, ou similar)

## Passo 1: Preparar o Repositório

```bash
# Clone o repositório ou faça upload dos arquivos
git init
git add .
git commit -m "Initial commit - GamePulse"
git remote add origin https://github.com/seu-usuario/game-pulse.git
git push -u origin main
```

## Passo 2: Configurar no Netlify

1. Acesse https://app.netlify.com
2. Clique em "Add new site" → "Import an existing project"
3. Selecione GitHub e autorize
4. Escolha o repositório `game-pulse`
5. Configure as build settings:
   - **Build command**: `pnpm install && pnpm build`
   - **Publish directory**: `dist`
   - **Functions directory**: `dist`

## Passo 3: Adicionar Variáveis de Ambiente

No Netlify, vá para **Site settings** → **Build & deploy** → **Environment**

Adicione as seguintes variáveis:

```
DATABASE_URL=mysql://user:password@host:3306/gamepulse
JWT_SECRET=seu-jwt-secret-aleatorio
VITE_APP_ID=seu-app-id-manus
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://manus.im/oauth
OWNER_OPEN_ID=seu-owner-id
OWNER_NAME=Seu Nome
BUILT_IN_FORGE_API_URL=https://api.manus.im/forge
BUILT_IN_FORGE_API_KEY=sua-chave-forge
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im/forge
VITE_FRONTEND_FORGE_API_KEY=sua-chave-frontend-forge
VITE_ANALYTICS_ENDPOINT=https://analytics.manus.im
VITE_ANALYTICS_WEBSITE_ID=seu-website-id
VITE_APP_TITLE=GamePulse
VITE_APP_LOGO=https://url-do-seu-logo.png
NODE_ENV=production
```

## Passo 4: Configurar Banco de Dados

1. Crie um banco de dados MySQL/TiDB
2. Execute as migrations do Drizzle:

```bash
pnpm drizzle-kit migrate
```

3. Atualize `DATABASE_URL` com a URL de conexão

## Passo 5: Deploy

1. Faça push para o GitHub
2. Netlify detectará automaticamente e iniciará o build
3. Após conclusão, seu site estará disponível em `seu-site.netlify.app`

## Troubleshooting

### Erro de build
- Verifique se todas as variáveis de ambiente estão configuradas
- Confirme que o `pnpm` está instalado: `npm install -g pnpm`

### Erro de conexão com banco de dados
- Teste a conexão localmente: `pnpm drizzle-kit push`
- Confirme que o IP do Netlify está whitelisted no banco de dados

### Erro de autenticação OAuth
- Verifique `VITE_APP_ID` e `OAUTH_SERVER_URL`
- Confirme que o domínio do Netlify está registrado no Manus

## Domínio Customizado

1. No Netlify, vá para **Domain management**
2. Clique em **Add custom domain**
3. Siga as instruções para atualizar os DNS records

## Monitoramento

- Acesse **Analytics** no Netlify para ver estatísticas
- Use **Functions** para monitorar erros do backend
- Configure **Notifications** para alertas de deploy

## Suporte

Para dúvidas sobre o GamePulse, consulte a documentação do projeto.
