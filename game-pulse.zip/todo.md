# GamePulse - TODO

## Banco de Dados & Schema

- [ ] Criar tabela `games` com informações dos 6 jogos
- [ ] Criar tabela `user_game_preferences` para salvar jogos favoritos por usuário
- [ ] Criar tabela `game_events` para armazenar eventos com status e contagem regressiva
- [ ] Criar tabela `twitch_drops` para campanhas de drops
- [ ] Criar tabela `feed_articles` para armazenar artigos de RSS/scraping
- [ ] Executar migrações SQL no banco de dados

## Backend - Consumidor de Feeds

- [ ] Implementar parser RSS para League of Legends (Riot News Feeds)
- [ ] Implementar parser RSS para CS2 (CS-RSS-Feed)
- [ ] Implementar parser RSS para Warhammer Darktide (Steam)
- [ ] Implementar parser RSS para Space Marine 2 (Steam)
- [ ] Implementar scraper para Marvel Rivals (www.marvelrivals.com/news/)
- [ ] Implementar scraper para Fortnite (www.fortnite.com/news)
- [ ] Implementar integração com Twitch Drops API
- [ ] Criar job cron para atualizar feeds a cada 1 hora

## Backend - Procedures tRPC

- [ ] Criar procedure `games.list` - listar todos os jogos
- [ ] Criar procedure `games.getDetails` - detalhes de um jogo específico
- [ ] Criar procedure `userPreferences.getGames` - obter jogos favoritos do usuário
- [ ] Criar procedure `userPreferences.setGames` - salvar jogos favoritos
- [ ] Criar procedure `dashboard.getEvents` - eventos dos jogos favoritos
- [ ] Criar procedure `dashboard.getDrops` - Twitch Drops ativos
- [ ] Criar procedure `dashboard.getFeed` - feed de notícias agregado
- [ ] Criar procedure `gameDetails.getEvents` - eventos de um jogo específico
- [ ] Criar procedure `gameDetails.getDrops` - drops de um jogo específico
- [ ] Criar procedure `gameDetails.getFeed` - feed de um jogo específico

## Frontend - Tema Retro-Futurista

- [x] Configurar paleta de cores (preto profundo, ciano neon, magenta)
- [x] Adicionar textura de scanlines no fundo
- [x] Implementar efeito de aberração cromática com CSS
- [x] Adicionar artefatos técnicos (códigos de erro, colchetes geométricos)
- [x] Configurar tipografia sans-serif bold branca
- [x] Criar componentes de status com indicadores visuais distintos

## Frontend - Páginas e Componentes

- [x] Criar página Home com autenticação e seleção de jogos
- [x] Criar dashboard personalizado com eventos e drops
- [ ] Criar página de detalhes por jogo
- [x] Criar componente de seleção de jogos favoritos
- [x] Criar componente de contagem regressiva (dias/horas)
- [x] Criar componente de Twitch Drops com links
- [x] Criar componente de feed de notícias
- [x] Criar componentes de status de evento (em andamento, próximo, encerrado)
- [x] Criar página de configurações (Settings)

## Frontend - Responsividade e UX

- [ ] Testar responsividade em mobile
- [ ] Implementar animações suaves
- [ ] Adicionar estados de carregamento
- [ ] Adicionar tratamento de erros com mensagens claras
- [ ] Implementar refresh manual de dados

## Assets Visuais

- [x] Gerar ícones dos 6 jogos com estética retro-futurista
- [ ] Gerar banners dos jogos
- [x] Assets armazenados em /manus-storage (S3)

## Testes

- [ ] Escrever testes unitários para procedures tRPC
- [ ] Testar parser RSS
- [ ] Testar scraper
- [ ] Testar integração com Twitch API
- [ ] Testar fluxo completo de autenticação e preferências

## Deploy

- [ ] Criar checkpoint final
- [ ] Publicar projeto


## Novas Funcionalidades - IA e Calendário

- [ ] Integrar LLM para gerar resumos de notícias/eventos
- [ ] Criar procedure tRPC para gerar resumos via IA
- [ ] Adicionar resumos no dashboard ao lado de cada notícia
- [ ] Criar página de Calendário interativo
- [ ] Implementar visualização de eventos por mês/semana
- [ ] Adicionar interatividade ao calendário (click em data para ver detalhes)
- [ ] Testar geração de resumos com diferentes tipos de conteúdo
- [ ] Testar navegação no calendário em mobile


## Sistema de Filtros

- [ ] Criar componente de filtro por jogos no Dashboard
- [ ] Criar componente de filtro por jogos no Calendário
- [ ] Implementar lógica de filtro no Dashboard (eventos/drops/feed)
- [ ] Implementar lógica de filtro no Calendário
- [ ] Persistir preferência de filtro no localStorage
- [ ] Testar filtros em diferentes combinações

## Categorização com IA

- [ ] Criar função de categorização de eventos/notícias
- [ ] Procedure tRPC para categorizar artigos
- [ ] Adicionar campo de categoria no banco de dados (opcional)
- [ ] Exibir tags de categoria nos cards de eventos
- [ ] Exibir tags de categoria nos cards de notícias
- [ ] Exibir tags de categoria no calendário
- [ ] Estilizar tags com cores distintas por categoria
- [ ] Testar categorização com diferentes tipos de conteúdo


## Aba de Últimas Notícias

- [x] Criar página News.tsx com timeline de notícias
- [x] Implementar filtro por data (últimos 2 meses)
- [x] Implementar filtro por jogo
- [x] Implementar filtro por tipo (passado/futuro)
- [x] Criar visualização de timeline vertical
- [x] Adicionar indicadores de data e hora
- [x] Adicionar rota /news no App.tsx
- [x] Adicionar botão de acesso na navegação
- [x] Testar timeline com dados reais


## Funcionalidade de Compartilhamento

- [x] Criar componente ShareButton.tsx
- [x] Implementar compartilhamento via WhatsApp
- [x] Implementar compartilhamento via Twitter/X
- [x] Implementar compartilhamento via Email
- [x] Implementar copiar link para clipboard
- [x] Adicionar botão nos cards de notícias (News.tsx)
- [x] Adicionar botão nos cards de eventos (Dashboard.tsx)
- [x] Adicionar botão nos cards de drops (Dashboard.tsx)
- [x] Adicionar toast de confirmação
- [x] Testar compartilhamento em todos os contextos


## Paginação e Rolagem Infinita

- [x] Implementar paginação na página de Notícias
- [x] Adicionar botão "Carregar Mais" ou rolagem infinita
- [x] Testar com múltiplas páginas de dados

## Barra de Pesquisa

- [x] Criar componente SearchBar.tsx
- [x] Implementar busca em tempo real
- [x] Filtrar por título, descrição e fonte
- [x] Integrar com página de Notícias
- [x] Testar busca com diferentes palavras-chave

## Dark Mode / Light Mode

- [x] Implementar toggle de tema no header
- [x] Salvar preferência de tema no localStorage
- [x] Aplicar tema em todos os componentes
- [x] Testar transição entre temas
- [x] Garantir acessibilidade em ambos os temas


## Sistema de Notícias Salvas

- [x] Criar componente SaveButton.tsx
- [x] Sincronizar salvos com localStorage
- [x] Adicionar botão de salvar em cada card
- [x] Criar aba "Salvos" na página de Notícias
- [x] Implementar visualização de notícias salvas
- [x] Adicionar contador de notícias salvas
- [x] Testar salvar e remover notícias
- [ ] Criar tabela savedArticles no banco de dados (opcional para persistência)
- [ ] Implementar procedure tRPC para salvar/remover artigos (opcional)


## Revisão e Correção de Links

- [x] Verificar e remover links duplicados
- [x] Corrigir links quebrados
- [x] Adicionar links para sites oficiais dos eventos
- [x] Validar URLs de todos os jogos
- [x] Testar funcionamento de todos os links


## Notificações Visuais Melhoradas

- [x] Melhorar toast de notícia salva
- [ ] Melhorar toast de problema reportado (ReportButton removido no rollback)
- [x] Adicionar ícones visuais nos toasts
- [x] Testar notificações em todos os fluxos

## Correção de Links de Notícias

- [x] Corrigir links para apontar direto ao artigo
- [x] Validar links de Warhammer
- [x] Testar todos os links

## Atualização de Dados de Notícias

- [x] Atualizar CS2 para Temporada 5
- [x] Atualizar Marvel Rivals para Temporada 9
- [x] Remover notícias desatualizadas
- [x] Inserir notícias atuais dos jogos


## Barra de Navegação Inferior Fixa (Mobile)

- [x] Criar componente BottomNav.tsx
- [x] Integrar no App.tsx
- [x] Ícones para Dashboard, Notícias, Favoritos, Calendário
- [x] Estilo responsivo (visível apenas em mobile)
- [x] Indicador de página ativa

## Filtros no Feed de Notícias

- [ ] Adicionar filtro por jogo
- [ ] Adicionar filtro por empresa
- [ ] Busca por palavra-chave
- [ ] Integrar com Dashboard e News

## Sistema de Favoritos (Notícias e Eventos)

- [x] Criar aba "Favoritos" no Dashboard
- [x] Salvar favoritos no localStorage
- [x] Botão de favoritar em cada card
- [ ] Sincronizar com banco de dados (opcional)
- [x] Contador de favoritos


## Settings - Toggle Dark/Light Mode

- [x] Adicionar toggle de tema na página Settings
- [x] Salvar preferência no localStorage
- [x] Sincronizar com ThemeProvider

## Pull-to-Refresh no Feed

- [x] Implementar componente de pull-to-refresh
- [x] Integrar com Dashboard e News
- [x] Atualizar dados ao fazer pull

## Categorização Automática

- [x] Remover botão "Categorizar" do feed
- [x] Aplicar categorização automática ao carregar
- [x] Exibir tags de categoria automaticamente

## Remover Botão Resumo

- [x] Remover botão "Gerar resumo"
- [x] Gerar resumos automaticamente ao carregar
- [x] Exibir resumos com IA automaticamente


## Melhorias de UX

- [ ] Adicionar animação suave na transição de temas
- [ ] Melhorar contraste de tags de categorias no modo escuro
- [ ] Separar Dashboard em abas (Eventos, Drops, Feed)
- [ ] Corrigir toggle Dark/Light Mode que não está funcionando


## Polling Automático (7 minutos)

- [x] Implementar hook useAutoRefresh para polling a cada 7 minutos
- [x] Adicionar no Dashboard, News e Favorites
- [x] Mostrar indicador de "última atualização"
- [x] Notificação ao carregar dados novos
- [x] Testar polling em diferentes páginas


## Badges de Notificação

- [x] Criar componente NotificationBadge com bolinha vermelha
- [x] Implementar detecção de novos dados (comparar antes/depois)
- [x] Adicionar badges nos ícones da BottomNav
- [x] Adicionar animação de pulsação
- [x] Limpar badge ao clicar na seção
- [x] Testar badges em todas as seções


## Botão Marcar Tudo como Lido

- [x] Adicionar botão no Dashboard
- [x] Implementar função clearAll no hook
- [x] Limpar todas as notificações ao clicar
- [x] Remover badges da BottomNav

## Histórico de Notificações

- [x] Criar componente NotificationHistory
- [x] Armazenar histórico em localStorage
- [x] Exibir últimas notificações no Dashboard
- [ ] Clicar para ir até a notícia
- [x] Limite de 20 notificações no histórico

## Animação de Pulso Melhorada

- [x] Aumentar intensidade da animação
- [x] Adicionar efeito de brilho neon
- [ ] Testar em diferentes navegadores


## Melhorias de Status de Eventos

- [x] Mudar "Encerra em" para "Chega em" para eventos futuros
- [x] Criar aba "Eventos Terminados" no Dashboard
- [x] Filtrar eventos por status (ativo, futuro, terminado)
- [x] Exibir eventos terminados em aba separada
- [x] Testar lógica de status em todos os cenários
