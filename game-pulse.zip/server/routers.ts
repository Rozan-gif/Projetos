import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { aiRouter } from "./routers-ai";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  games: router({
    list: publicProcedure.query(() => db.getAllGames()),
    getBySlug: publicProcedure
      .input(z.string())
      .query(({ input }) => db.getGameBySlug(input)),
  }),

  userPreferences: router({
    getGames: protectedProcedure.query(({ ctx }) =>
      db.getUserGamePreferences(ctx.user.id)
    ),
    setGames: protectedProcedure
      .input(z.array(z.number()))
      .mutation(async ({ ctx, input }) => {
        await db.setUserGamePreferences(ctx.user.id, input);
        return { success: true };
      }),
  }),

  dashboard: router({
    getEvents: protectedProcedure.query(async ({ ctx }) => {
      const prefs = await db.getUserGamePreferences(ctx.user.id);
      const gameIds = prefs.map(p => (p as any).game.id);
      if (gameIds.length === 0) return [];
      return db.getUpcomingEventsByGameIds(gameIds);
    }),
    getDrops: protectedProcedure.query(async ({ ctx }) => {
      const prefs = await db.getUserGamePreferences(ctx.user.id);
      const gameIds = prefs.map(p => (p as any).game.id);
      const drops = await db.getActiveTwitchDrops();
      return drops.filter(d => gameIds.includes(d.gameId));
    }),
    getFeed: protectedProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ ctx, input }) => {
        const prefs = await db.getUserGamePreferences(ctx.user.id);
        const gameIds = prefs.map(p => (p as any).game.id);
        if (gameIds.length === 0) return [];
        return db.getRecentFeedArticles(gameIds, input.limit || 50);
      }),
  }),

  gameDetails: router({
    getEvents: publicProcedure
      .input(z.number())
      .query(({ input }) => db.getGameEvents(input)),
    getDrops: publicProcedure
      .input(z.number())
      .query(({ input }) => db.getTwitchDrops(input)),
    getFeed: publicProcedure
      .input(z.number())
      .query(({ input }) => db.getFeedArticles(input, 50)),
  }),

  ai: aiRouter,
});

export type AppRouter = typeof appRouter;
