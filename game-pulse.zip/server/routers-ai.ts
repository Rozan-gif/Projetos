import { protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { categorizeContent } from "./ai-categorizer";

export const aiRouter = router({
  summarizeArticle: protectedProcedure
    .input(z.object({
      title: z.string(),
      description: z.string().optional(),
      content: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const { generateSummary } = await import('./ai-summarizer');
      return generateSummary(input.title, input.description, input.content);
    }),

  categorizeContent: protectedProcedure
    .input(z.object({
      title: z.string(),
      description: z.string().optional(),
      content: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      return categorizeContent(input.title, input.description, input.content);
    }),
});
