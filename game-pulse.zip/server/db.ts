import { eq, and, or, inArray, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, games, userGamePreferences, gameEvents, twitchDrops, feedArticles, feedSyncStatus, InsertFeedArticle } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Games queries
export async function getAllGames() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(games);
}

export async function getGameBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(games).where(eq(games.slug, slug)).limit(1);
  return result[0];
}

// User preferences queries
export async function getUserGamePreferences(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ game: games }).from(userGamePreferences)
    .innerJoin(games, eq(userGamePreferences.gameId, games.id))
    .where(eq(userGamePreferences.userId, userId));
}

export async function setUserGamePreferences(userId: number, gameIds: number[]) {
  const db = await getDb();
  if (!db) return;
  
  // Delete existing preferences
  await db.delete(userGamePreferences).where(eq(userGamePreferences.userId, userId));
  
  // Insert new preferences
  if (gameIds.length > 0) {
    await db.insert(userGamePreferences).values(
      gameIds.map(gameId => ({ userId, gameId }))
    );
  }
}

// Events queries
export async function getGameEvents(gameId: number, status?: string) {
  const db = await getDb();
  if (!db) return [];
  
  if (status) {
    return db.select().from(gameEvents)
      .where(
        and(
          eq(gameEvents.gameId, gameId),
          eq(gameEvents.status, status as any)
        )
      );
  }
  return db.select().from(gameEvents).where(eq(gameEvents.gameId, gameId));
}

export async function getUpcomingEventsByGameIds(gameIds: number[]) {
  const db = await getDb();
  if (!db) return [];
  if (gameIds.length === 0) return [];
  
  return db.select().from(gameEvents)
    .where(
      and(
        inArray(gameEvents.gameId, gameIds),
        or(
          eq(gameEvents.status, 'active'),
          eq(gameEvents.status, 'upcoming')
        )
      )
    )
    .orderBy(gameEvents.startDate);
}

// Twitch Drops queries
export async function getTwitchDrops(gameId?: number, status?: string) {
  const db = await getDb();
  if (!db) return [];
  
  const conditions = [];
  if (gameId) conditions.push(eq(twitchDrops.gameId, gameId));
  if (status) conditions.push(eq(twitchDrops.status, status as any));
  
  if (conditions.length === 0) {
    return db.select().from(twitchDrops);
  }
  
  return db.select().from(twitchDrops).where(and(...conditions));
}

export async function getActiveTwitchDrops() {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(twitchDrops)
    .where(
      or(
        eq(twitchDrops.status, 'active'),
        eq(twitchDrops.status, 'upcoming')
      )
    )
    .orderBy(twitchDrops.startDate);
}

// Feed articles queries
export async function getFeedArticles(gameId: number, limit: number = 20) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(feedArticles)
    .where(eq(feedArticles.gameId, gameId))
    .orderBy(desc(feedArticles.publishedAt))
    .limit(limit);
}

export async function getRecentFeedArticles(gameIds: number[], limit: number = 50) {
  const db = await getDb();
  if (!db) return [];
  if (gameIds.length === 0) return [];
  
  return db.select().from(feedArticles)
    .where(inArray(feedArticles.gameId, gameIds))
    .orderBy(desc(feedArticles.publishedAt))
    .limit(limit);
}

export async function upsertFeedArticle(article: InsertFeedArticle) {
  const db = await getDb();
  if (!db) return;
  
  await db.insert(feedArticles).values(article).onDuplicateKeyUpdate({
    set: {
      title: article.title,
      description: article.description,
      content: article.content,
      imageUrl: article.imageUrl,
      publishedAt: article.publishedAt,
      updatedAt: new Date(),
    },
  });
}

// Feed sync status queries
export async function getFeedSyncStatus(gameId: number, feedType: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(feedSyncStatus)
    .where(
      and(
        eq(feedSyncStatus.gameId, gameId),
        eq(feedSyncStatus.feedType, feedType)
      )
    )
    .limit(1);
  
  return result[0];
}

export async function updateFeedSyncStatus(
  gameId: number,
  feedType: string,
  status: 'pending' | 'syncing' | 'success' | 'error',
  errorMessage?: string
) {
  const db = await getDb();
  if (!db) return;
  
  const existing = await getFeedSyncStatus(gameId, feedType);
  
  if (existing) {
    await db.update(feedSyncStatus)
      .set({
        syncStatus: status,
        lastSyncAt: status === 'success' ? new Date() : existing.lastSyncAt,
        errorMessage: errorMessage || null,
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(feedSyncStatus.gameId, gameId),
          eq(feedSyncStatus.feedType, feedType)
        )
      );
  } else {
    await db.insert(feedSyncStatus).values({
      gameId,
      feedType,
      syncStatus: status,
      lastSyncAt: status === 'success' ? new Date() : undefined,
      errorMessage: errorMessage || null,
    });
  }
}

// TODO: add more feature queries here as your schema grows.
