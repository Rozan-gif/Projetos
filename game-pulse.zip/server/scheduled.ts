import { Router } from 'express';
import { runFullSyncCycle, cleanupOldArticles } from './feeds/sync-service';

const router = Router();

/**
 * Scheduled endpoint for full feed sync
 * Called by Heartbeat cron every hour
 */
router.post('/api/scheduled/sync-feeds', async (req, res) => {
  try {
    console.log('[Scheduled] Received sync-feeds request');
    await runFullSyncCycle();
    res.json({ success: true, message: 'Feed sync completed' });
  } catch (error) {
    console.error('[Scheduled] Error in sync-feeds:', error);
    res.status(500).json({ success: false, error: String(error) });
  }
});

/**
 * Scheduled endpoint for cleanup
 * Called by Heartbeat cron daily
 */
router.post('/api/scheduled/cleanup', async (req, res) => {
  try {
    console.log('[Scheduled] Received cleanup request');
    await cleanupOldArticles();
    res.json({ success: true, message: 'Cleanup completed' });
  } catch (error) {
    console.error('[Scheduled] Error in cleanup:', error);
    res.status(500).json({ success: false, error: String(error) });
  }
});

export default router;
