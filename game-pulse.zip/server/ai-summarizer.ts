import { invokeLLM } from './_core/llm';

export interface SummaryResult {
  summary: string;
  confidence: number;
}

/**
 * Generate a 1-2 sentence summary of a news article or event using LLM
 */
export async function generateSummary(
  title: string,
  description: string | undefined,
  content: string | undefined
): Promise<SummaryResult> {
  try {
    // Combine available text
    const textToSummarize = [title, description, content]
      .filter(Boolean)
      .join('\n\n');

    if (!textToSummarize.trim()) {
      return {
        summary: title || 'Sem descrição disponível',
        confidence: 0.5,
      };
    }

    const response = await invokeLLM({
      model: 'gpt-5-mini', // Fast and cheap for summarization
      messages: [
        {
          role: 'system',
          content: 'You are a concise summarizer. Summarize the given text in exactly 1-2 sentences. Be direct and informative.',
        },
        {
          role: 'user',
          content: `Summarize this in 1-2 sentences:\n\n${textToSummarize}`,
        },
      ],
    });

    const summaryContent = response.choices[0].message.content;
    const summary = typeof summaryContent === 'string' ? summaryContent : title;

    return {
      summary: summary.trim(),
      confidence: 0.95,
    };
  } catch (error) {
    console.error('Error generating summary:', error);
    // Fallback to title if LLM fails
    return {
      summary: title || 'Notícia disponível',
      confidence: 0.3,
    };
  }
}

/**
 * Generate summaries for multiple articles/events in parallel
 */
export async function generateSummariesBatch(
  items: Array<{
    id: number;
    title: string;
    description?: string;
    content?: string;
  }>
): Promise<Map<number, SummaryResult>> {
  const results = new Map<number, SummaryResult>();

  // Process in batches of 5 to avoid rate limiting
  const batchSize = 5;
  for (let i = 0; i < items.length; i += batchSize) {
    const batch = items.slice(i, i + batchSize);
    const promises = batch.map(item =>
      generateSummary(item.title, item.description, item.content)
        .then(summary => ({ id: item.id, summary }))
        .catch(error => {
          console.error(`Error summarizing item ${item.id}:`, error);
          return {
            id: item.id,
            summary: {
              summary: item.title,
              confidence: 0.3,
            },
          };
        })
    );

    const batchResults = await Promise.all(promises);
    batchResults.forEach(({ id, summary }) => {
      results.set(id, summary);
    });

    // Add small delay between batches to avoid rate limiting
    if (i + batchSize < items.length) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }

  return results;
}
