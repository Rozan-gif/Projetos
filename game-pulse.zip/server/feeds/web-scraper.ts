import { load } from 'cheerio';
import { InsertFeedArticle } from '../../drizzle/schema';

export interface ScrapedArticle {
  title: string;
  description?: string;
  link: string;
  pubDate?: string;
  image?: string;
  guid?: string;
}

/**
 * Scrape Marvel Rivals news from official website
 */
export async function scrapeMarvelRivalsNews(): Promise<ScrapedArticle[]> {
  try {
    const response = await fetch('https://www.marvelrivals.com/news/', {
      headers: {
        'User-Agent': 'GamePulse/1.0 (+https://gamepulse.app)',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch Marvel Rivals news: ${response.statusText}`);
    }

    const html = await response.text();
    const $ = load(html);
    const articles: ScrapedArticle[] = [];

    // Parse Marvel Rivals news structure
    // This is a basic example - adjust selectors based on actual HTML structure
    $('article, .news-item, .post').each((_, element) => {
      const $elem = $(element);
      const title = $elem.find('h2, h3, .title').text().trim();
      const link = $elem.find('a').attr('href') || '';
      const description = $elem.find('p, .description, .excerpt').text().trim();
      const image = $elem.find('img').attr('src') || '';
      const pubDate = $elem.find('time, .date, .published').attr('datetime') || '';

      if (title && link) {
        articles.push({
          title,
          description,
          link: link.startsWith('http') ? link : `https://www.marvelrivals.com${link}`,
          pubDate,
          image: image.startsWith('http') ? image : `https://www.marvelrivals.com${image}`,
          guid: link,
        });
      }
    });

    return articles;
  } catch (error) {
    console.error('Error scraping Marvel Rivals news:', error);
    throw error;
  }
}

/**
 * Scrape Fortnite news from official website
 */
export async function scrapeFortniteNews(): Promise<ScrapedArticle[]> {
  try {
    const response = await fetch('https://www.fortnite.com/news', {
      headers: {
        'User-Agent': 'GamePulse/1.0 (+https://gamepulse.app)',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch Fortnite news: ${response.statusText}`);
    }

    const html = await response.text();
    const $ = load(html);
    const articles: ScrapedArticle[] = [];

    // Parse Fortnite news structure
    // This is a basic example - adjust selectors based on actual HTML structure
    $('article, .news-item, [data-news-item]').each((_, element) => {
      const $elem = $(element);
      const title = $elem.find('h2, h3, .title, [data-title]').text().trim();
      const link = $elem.find('a').attr('href') || '';
      const description = $elem.find('p, .description, .excerpt, [data-description]').text().trim();
      const image = $elem.find('img').attr('src') || '';
      const pubDate = $elem.find('time, .date, .published, [data-date]').attr('datetime') || '';

      if (title && link) {
        articles.push({
          title,
          description,
          link: link.startsWith('http') ? link : `https://www.fortnite.com${link}`,
          pubDate,
          image: image.startsWith('http') ? image : `https://www.fortnite.com${image}`,
          guid: link,
        });
      }
    });

    return articles;
  } catch (error) {
    console.error('Error scraping Fortnite news:', error);
    throw error;
  }
}

/**
 * Convert scraped article to database article
 */
export function convertScrapedArticleToArticle(
  article: ScrapedArticle,
  gameId: number,
  source: string
): InsertFeedArticle {
  return {
    gameId,
    title: article.title,
    description: article.description,
    content: article.description,
    imageUrl: article.image,
    externalUrl: article.link,
    source,
    externalId: article.guid,
    publishedAt: article.pubDate ? new Date(article.pubDate) : new Date(),
  };
}
