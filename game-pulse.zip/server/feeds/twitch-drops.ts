import { InsertTwitchDrop } from '../../drizzle/schema';

export interface TwitchDropCampaign {
  id: string;
  broadcasterId: string;
  broadcasterName: string;
  broadcasterLogin: string;
  name: string;
  description: string;
  status: 'ACTIVE' | 'UPCOMING' | 'EXPIRED';
  startDate: string;
  endDate: string;
  imageUrl: string;
}

export interface TwitchDropReward {
  id: string;
  campaignId: string;
  name: string;
  description: string;
  imageUrl: string;
}

/**
 * Get Twitch drops campaigns for a specific game
 * Note: This requires Twitch OAuth token or uses public API
 */
export async function getTwitchDropCampaigns(
  gameId: string,
  accessToken?: string
): Promise<TwitchDropCampaign[]> {
  try {
    // Using Twitch API endpoint for drops campaigns
    // This is a simplified version - actual implementation would need proper OAuth
    const url = new URL('https://api.twitch.tv/helix/drops/campaigns');
    url.searchParams.append('first', '100');

    const headers: Record<string, string> = {
      'User-Agent': 'GamePulse/1.0 (+https://gamepulse.app)',
      'Client-ID': process.env.TWITCH_CLIENT_ID || '',
    };

    if (accessToken) {
      headers['Authorization'] = `Bearer ${accessToken}`;
    }

    const response = await fetch(url.toString(), { headers });

    if (!response.ok) {
      if (response.status === 401) {
        console.warn('Twitch API authentication failed - using fallback');
        return [];
      }
      throw new Error(`Failed to fetch Twitch drops: ${response.statusText}`);
    }

    const data = (await response.json()) as any;
    const campaigns = data.data || [];

    return campaigns.map((campaign: any) => ({
      id: campaign.id,
      broadcasterId: campaign.broadcaster_id,
      broadcasterName: campaign.broadcaster_name,
      broadcasterLogin: campaign.broadcaster_login,
      name: campaign.name,
      description: campaign.description || '',
      status: campaign.status,
      startDate: campaign.started_at,
      endDate: campaign.ended_at,
      imageUrl: campaign.image_url || '',
    }));
  } catch (error) {
    console.error('Error fetching Twitch drops campaigns:', error);
    return [];
  }
}

/**
 * Get rewards for a specific Twitch drops campaign
 */
export async function getTwitchDropRewards(
  campaignId: string,
  accessToken?: string
): Promise<TwitchDropReward[]> {
  try {
    const url = new URL('https://api.twitch.tv/helix/drops/entitlements');
    url.searchParams.append('campaign_id', campaignId);
    url.searchParams.append('first', '100');

    const headers: Record<string, string> = {
      'User-Agent': 'GamePulse/1.0 (+https://gamepulse.app)',
      'Client-ID': process.env.TWITCH_CLIENT_ID || '',
    };

    if (accessToken) {
      headers['Authorization'] = `Bearer ${accessToken}`;
    }

    const response = await fetch(url.toString(), { headers });

    if (!response.ok) {
      console.warn(`Failed to fetch rewards for campaign ${campaignId}`);
      return [];
    }

    const data = (await response.json()) as any;
    const rewards = data.data || [];

    return rewards.map((reward: any) => ({
      id: reward.id,
      campaignId: reward.campaign_id,
      name: reward.name,
      description: reward.description || '',
      imageUrl: reward.image_url || '',
    }));
  } catch (error) {
    console.error('Error fetching Twitch drop rewards:', error);
    return [];
  }
}

/**
 * Convert Twitch campaign to database drop
 */
export function convertTwitchCampaignToDrop(
  campaign: TwitchDropCampaign,
  gameId: number
): InsertTwitchDrop {
  return {
    gameId,
    campaignId: campaign.id,
    title: campaign.name,
    description: campaign.description,
    rewards: JSON.stringify([]), // Would be populated with actual rewards
    startDate: new Date(campaign.startDate),
    endDate: new Date(campaign.endDate),
    status: campaign.status === 'ACTIVE' ? 'active' : campaign.status === 'UPCOMING' ? 'upcoming' : 'ended',
    watchUrl: `https://www.twitch.tv/directory/game/${campaign.broadcasterId}`,
    externalData: JSON.stringify(campaign),
  };
}

/**
 * Map Twitch game name to our internal game slug
 */
export function mapTwitchGameToGameSlug(twitchGameName: string): string | null {
  const mapping: Record<string, string> = {
    'League of Legends': 'lol',
    'Fortnite': 'fortnite',
    'Counter-Strike 2': 'cs2',
    'Counter-Strike: Global Offensive': 'cs2',
    'Marvel Rivals': 'marvel-rivals',
    'Warhammer: Darktide': 'darktide',
    'Warhammer 40,000: Space Marine 2': 'space-marine-2',
    'Space Marine 2': 'space-marine-2',
  };

  return mapping[twitchGameName] || null;
}
