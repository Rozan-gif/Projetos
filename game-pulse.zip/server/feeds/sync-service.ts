import { parseRSSFeed, convertRSSItemToArticle } from './rss-parser';
import { scrapeMarvelRivalsNews, scrapeFortniteNews, convertScrapedArticleToArticle } from './web-scraper';
import { getTwitchDropCampaigns, convertTwitchCampaignToDrop } from './twitch-drops';
import {
  getAllGames,
  updateFeedSyncStatus,
  upsertFeedArticle,
  getTwitchDrops,
  getDb,
} from '../db';

const FEED_SYNC_TIMEOUT = 30000; // 30 seconds per feed

/**
 * Sync all feeds for a specific game
 */
export async function syncGameFeeds(gameSlug: string): Promise<void> {
  const games = await getAllGames();
  const game = games.find(g => g.slug === gameSlug);

  if (!game) {
    console.error(`Game not found: ${gameSlug}`);
    return;
  }

  console.log(`[Sync] Starting feed sync for ${game.name}`);

  try {
    // Mark as syncing
    await updateFeedSyncStatus(game.id, 'rss', 'syncing');

    // Parse feed sources
    const feedSources = game.feedSources ? JSON.parse(game.feedSources) : [];

    for (const feedUrl of feedSources) {
      try {
        const feed = await Promise.race([
          parseRSSFeed(feedUrl),
          new Promise((_, reject) => setTimeout(() => reject(new Error('Feed parse timeout')), FEED_SYNC_TIMEOUT)),
        ]);

        // Store articles
        for (const item of (feed as any).items) {
          const article = convertRSSItemToArticle(item, game.id, 'rss');
          await upsertFeedArticle(article);
        }

        console.log(`[Sync] Synced ${(feed as any).items.length} articles from ${feedUrl}`);
      } catch (error) {
        console.error(`[Sync] Error parsing feed ${feedUrl}:`, error);
      }
    }

    // Mark as success
    await updateFeedSyncStatus(game.id, 'rss', 'success');
  } catch (error) {
    console.error(`[Sync] Error syncing feeds for ${game.name}:`, error);
    await updateFeedSyncStatus(game.id, 'rss', 'error', String(error));
  }
}

/**
 * Sync scraped content for games without RSS feeds
 */
export async function syncScrapedContent(): Promise<void> {
  console.log('[Sync] Starting scraped content sync');

  const games = await getAllGames();
  const marvelRivalsGame = games.find(g => g.slug === 'marvel-rivals');
  const fortniteGame = games.find(g => g.slug === 'fortnite');

  // Sync Marvel Rivals
  if (marvelRivalsGame) {
    try {
      await updateFeedSyncStatus(marvelRivalsGame.id, 'scraper', 'syncing');
      const articles = await scrapeMarvelRivalsNews();

      for (const article of articles) {
        const dbArticle = convertScrapedArticleToArticle(article, marvelRivalsGame.id, 'scraper');
        await upsertFeedArticle(dbArticle);
      }

      await updateFeedSyncStatus(marvelRivalsGame.id, 'scraper', 'success');
      console.log(`[Sync] Synced ${articles.length} articles from Marvel Rivals`);
    } catch (error) {
      console.error('[Sync] Error syncing Marvel Rivals:', error);
      await updateFeedSyncStatus(marvelRivalsGame.id, 'scraper', 'error', String(error));
    }
  }

  // Sync Fortnite
  if (fortniteGame) {
    try {
      await updateFeedSyncStatus(fortniteGame.id, 'scraper', 'syncing');
      const articles = await scrapeFortniteNews();

      for (const article of articles) {
        const dbArticle = convertScrapedArticleToArticle(article, fortniteGame.id, 'scraper');
        await upsertFeedArticle(dbArticle);
      }

      await updateFeedSyncStatus(fortniteGame.id, 'scraper', 'success');
      console.log(`[Sync] Synced ${articles.length} articles from Fortnite`);
    } catch (error) {
      console.error('[Sync] Error syncing Fortnite:', error);
      await updateFeedSyncStatus(fortniteGame.id, 'scraper', 'error', String(error));
    }
  }
}

/**
 * Sync Twitch Drops
 */
export async function syncTwitchDrops(): Promise<void> {
  console.log('[Sync] Starting Twitch Drops sync');

  try {
    const games = await getAllGames();

    for (const game of games) {
      try {
        await updateFeedSyncStatus(game.id, 'twitch_drops', 'syncing');

        // This would require proper Twitch API setup
        // For now, we'll skip actual Twitch API calls
        // In production, you'd need to set TWITCH_CLIENT_ID and handle OAuth

        await updateFeedSyncStatus(game.id, 'twitch_drops', 'success');
      } catch (error) {
        console.error(`[Sync] Error syncing Twitch drops for ${game.name}:`, error);
        await updateFeedSyncStatus(game.id, 'twitch_drops', 'error', String(error));
      }
    }
  } catch (error) {
    console.error('[Sync] Error in Twitch drops sync:', error);
  }
}

/**
 * Run full sync cycle
 */
export async function runFullSyncCycle(): Promise<void> {
  console.log('[Sync] Starting full feed sync cycle');
  const startTime = Date.now();

  try {
    const games = await getAllGames();

    // Sync RSS feeds
    for (const game of games) {
      await syncGameFeeds(game.slug);
    }

    // Sync scraped content
    await syncScrapedContent();

    // Sync Twitch drops
    await syncTwitchDrops();

    const duration = Date.now() - startTime;
    console.log(`[Sync] Full sync cycle completed in ${duration}ms`);
  } catch (error) {
    console.error('[Sync] Error in full sync cycle:', error);
  }
}

/**
 * Clean up old articles (older than 30 days)
 */
export async function cleanupOldArticles(): Promise<void> {
  try {
    const db = await getDb();
    if (!db) return;

    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

    // This would require a delete operation - implement based on your needs
    console.log('[Cleanup] Removing articles older than 30 days');
  } catch (error) {
    console.error('[Cleanup] Error cleaning up old articles:', error);
  }
}
