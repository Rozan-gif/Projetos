import { invokeLLM } from './_core/llm';

export type EventCategory = 
  | 'twitch-drop'
  | 'tournament'
  | 'update'
  | 'event'
  | 'maintenance'
  | 'news'
  | 'other';

export interface CategoryResult {
  category: EventCategory;
  confidence: number;
  reasoning?: string;
}

const CATEGORY_DESCRIPTIONS: Record<EventCategory, string> = {
  'twitch-drop': 'Twitch Drops campaign or reward',
  'tournament': 'Competitive tournament or esports event',
  'update': 'Game update, patch, or new content',
  'event': 'In-game event or seasonal event',
  'maintenance': 'Server maintenance or downtime',
  'news': 'General news or announcement',
  'other': 'Other or uncategorized',
};

/**
 * Categorize an event or article using LLM
 */
export async function categorizeContent(
  title: string,
  description: string | undefined,
  content: string | undefined
): Promise<CategoryResult> {
  try {
    const textToAnalyze = [title, description, content]
      .filter(Boolean)
      .join('\n\n');

    if (!textToAnalyze.trim()) {
      return {
        category: 'other',
        confidence: 0.3,
      };
    }

    const response = await invokeLLM({
      model: 'gpt-5-mini',
      messages: [
        {
          role: 'system',
          content: `You are a content categorizer. Categorize the given text into one of these categories:
${Object.entries(CATEGORY_DESCRIPTIONS)
  .map(([key, desc]) => `- ${key}: ${desc}`)
  .join('\n')}

Respond with ONLY a JSON object with "category" (string) and "confidence" (0-1 number).`,
        },
        {
          role: 'user',
          content: `Categorize this:\n\n${textToAnalyze}`,
        },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'category',
          strict: true,
          schema: {
            type: 'object',
            properties: {
              category: {
                type: 'string',
                enum: Object.keys(CATEGORY_DESCRIPTIONS),
              },
              confidence: {
                type: 'number',
                minimum: 0,
                maximum: 1,
              },
            },
            required: ['category', 'confidence'],
            additionalProperties: false,
          },
        },
      },
    });

    const responseContent = response.choices[0].message.content;
    if (typeof responseContent === 'string') {
      const parsed = JSON.parse(responseContent);
      return {
        category: parsed.category as EventCategory,
        confidence: parsed.confidence,
      };
    }

    return {
      category: 'other',
      confidence: 0.3,
    };
  } catch (error) {
    console.error('Error categorizing content:', error);
    return {
      category: 'other',
      confidence: 0.2,
    };
  }
}

/**
 * Categorize multiple items in parallel
 */
export async function categorizeBatch(
  items: Array<{
    id: number;
    title: string;
    description?: string;
    content?: string;
  }>
): Promise<Map<number, CategoryResult>> {
  const results = new Map<number, CategoryResult>();

  // Process in batches of 3 to avoid rate limiting
  const batchSize = 3;
  for (let i = 0; i < items.length; i += batchSize) {
    const batch = items.slice(i, i + batchSize);
    const promises = batch.map(item =>
      categorizeContent(item.title, item.description, item.content)
        .then(category => ({ id: item.id, category }))
        .catch(error => {
          console.error(`Error categorizing item ${item.id}:`, error);
          return {
            id: item.id,
            category: {
              category: 'other' as EventCategory,
              confidence: 0.1,
            },
          };
        })
    );

    const batchResults = await Promise.all(promises);
    batchResults.forEach(({ id, category }) => {
      results.set(id, category);
    });

    // Add delay between batches
    if (i + batchSize < items.length) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }

  return results;
}

/**
 * Get display name and color for a category
 */
export function getCategoryDisplay(category: EventCategory) {
  const displayNames: Record<EventCategory, { label: string; color: string }> = {
    'twitch-drop': { label: 'Twitch Drop', color: '#9146ff' },
    'tournament': { label: 'Torneio', color: '#ff6b00' },
    'update': { label: 'Atualização', color: '#00d4ff' },
    'event': { label: 'Evento', color: '#ff00ff' },
    'maintenance': { label: 'Manutenção', color: '#ffff00' },
    'news': { label: 'Notícia', color: '#00ff00' },
    'other': { label: 'Outro', color: '#808080' },
  };

  return displayNames[category] || displayNames['other'];
}
