import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Games table
export const games = mysqlTable("games", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 64 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  officialUrl: varchar("officialUrl", { length: 512 }),
  feedSources: text("feedSources"), // JSON array of feed URLs
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Game = typeof games.$inferSelect;
export type InsertGame = typeof games.$inferInsert;

// User game preferences
export const userGamePreferences = mysqlTable("user_game_preferences", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  gameId: int("gameId").notNull().references(() => games.id, { onDelete: "cascade" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UserGamePreference = typeof userGamePreferences.$inferSelect;
export type InsertUserGamePreference = typeof userGamePreferences.$inferInsert;

// Game events
export const gameEvents = mysqlTable("game_events", {
  id: int("id").autoincrement().primaryKey(),
  gameId: int("gameId").notNull().references(() => games.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 512 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["active", "upcoming", "ended"]).notNull(),
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  externalUrl: varchar("externalUrl", { length: 512 }),
  source: varchar("source", { length: 64 }), // e.g., "official", "steam", "twitch"
  externalId: varchar("externalId", { length: 255 }).unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type GameEvent = typeof gameEvents.$inferSelect;
export type InsertGameEvent = typeof gameEvents.$inferInsert;

// Twitch Drops
export const twitchDrops = mysqlTable("twitch_drops", {
  id: int("id").autoincrement().primaryKey(),
  gameId: int("gameId").notNull().references(() => games.id, { onDelete: "cascade" }),
  campaignId: varchar("campaignId", { length: 255 }).notNull().unique(),
  title: varchar("title", { length: 512 }).notNull(),
  description: text("description"),
  rewards: text("rewards"), // JSON array of rewards
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  status: mysqlEnum("status", ["active", "upcoming", "ended"]).notNull(),
  watchUrl: varchar("watchUrl", { length: 512 }),
  externalData: text("externalData"), // JSON for storing raw Twitch data
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TwitchDrop = typeof twitchDrops.$inferSelect;
export type InsertTwitchDrop = typeof twitchDrops.$inferInsert;

// Feed articles
export const feedArticles = mysqlTable("feed_articles", {
  id: int("id").autoincrement().primaryKey(),
  gameId: int("gameId").notNull().references(() => games.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 512 }).notNull(),
  description: text("description"),
  content: text("content"),
  author: varchar("author", { length: 255 }),
  imageUrl: varchar("imageUrl", { length: 512 }),
  externalUrl: varchar("externalUrl", { length: 512 }).notNull(),
  source: varchar("source", { length: 64 }), // e.g., "rss", "steam", "official"
  externalId: varchar("externalId", { length: 255 }).unique(),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FeedArticle = typeof feedArticles.$inferSelect;
export type InsertFeedArticle = typeof feedArticles.$inferInsert;

// Feed sync status (to track last update per game)
export const feedSyncStatus = mysqlTable("feed_sync_status", {
  id: int("id").autoincrement().primaryKey(),
  gameId: int("gameId").notNull().references(() => games.id, { onDelete: "cascade" }),
  feedType: varchar("feedType", { length: 64 }).notNull(), // e.g., "rss", "twitch_drops", "events"
  lastSyncAt: timestamp("lastSyncAt"),
  syncStatus: mysqlEnum("syncStatus", ["pending", "syncing", "success", "error"]).default("pending"),
  errorMessage: text("errorMessage"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FeedSyncStatus = typeof feedSyncStatus.$inferSelect;
export type InsertFeedSyncStatus = typeof feedSyncStatus.$inferInsert;
// Bug Reports
export const bugReports = mysqlTable("bug_reports", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  itemType: mysqlEnum("itemType", ["event", "article", "drop", "other"]).notNull(),
  itemId: int("itemId"),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  problemType: mysqlEnum("problemType", ["link_broken", "wrong_info", "duplicate", "other"]).notNull(),
  status: mysqlEnum("status", ["open", "in_progress", "resolved", "closed"]).default("open").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BugReport = typeof bugReports.$inferSelect;
export type InsertBugReport = typeof bugReports.$inferInsert;
