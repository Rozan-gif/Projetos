CREATE TABLE `feed_articles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`gameId` int NOT NULL,
	`title` varchar(512) NOT NULL,
	`description` text,
	`content` text,
	`author` varchar(255),
	`imageUrl` varchar(512),
	`externalUrl` varchar(512) NOT NULL,
	`source` varchar(64),
	`externalId` varchar(255),
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `feed_articles_id` PRIMARY KEY(`id`),
	CONSTRAINT `feed_articles_externalId_unique` UNIQUE(`externalId`)
);
--> statement-breakpoint
CREATE TABLE `feed_sync_status` (
	`id` int AUTO_INCREMENT NOT NULL,
	`gameId` int NOT NULL,
	`feedType` varchar(64) NOT NULL,
	`lastSyncAt` timestamp,
	`syncStatus` enum('pending','syncing','success','error') DEFAULT 'pending',
	`errorMessage` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `feed_sync_status_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `game_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`gameId` int NOT NULL,
	`title` varchar(512) NOT NULL,
	`description` text,
	`status` enum('active','upcoming','ended') NOT NULL,
	`startDate` timestamp,
	`endDate` timestamp,
	`externalUrl` varchar(512),
	`source` varchar(64),
	`externalId` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `game_events_id` PRIMARY KEY(`id`),
	CONSTRAINT `game_events_externalId_unique` UNIQUE(`externalId`)
);
--> statement-breakpoint
CREATE TABLE `games` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(64) NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`officialUrl` varchar(512),
	`feedSources` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `games_id` PRIMARY KEY(`id`),
	CONSTRAINT `games_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `twitch_drops` (
	`id` int AUTO_INCREMENT NOT NULL,
	`gameId` int NOT NULL,
	`campaignId` varchar(255) NOT NULL,
	`title` varchar(512) NOT NULL,
	`description` text,
	`rewards` text,
	`startDate` timestamp,
	`endDate` timestamp,
	`status` enum('active','upcoming','ended') NOT NULL,
	`watchUrl` varchar(512),
	`externalData` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `twitch_drops_id` PRIMARY KEY(`id`),
	CONSTRAINT `twitch_drops_campaignId_unique` UNIQUE(`campaignId`)
);
--> statement-breakpoint
CREATE TABLE `user_game_preferences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`gameId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `user_game_preferences_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `feed_articles` ADD CONSTRAINT `feed_articles_gameId_games_id_fk` FOREIGN KEY (`gameId`) REFERENCES `games`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `feed_sync_status` ADD CONSTRAINT `feed_sync_status_gameId_games_id_fk` FOREIGN KEY (`gameId`) REFERENCES `games`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `game_events` ADD CONSTRAINT `game_events_gameId_games_id_fk` FOREIGN KEY (`gameId`) REFERENCES `games`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `twitch_drops` ADD CONSTRAINT `twitch_drops_gameId_games_id_fk` FOREIGN KEY (`gameId`) REFERENCES `games`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `user_game_preferences` ADD CONSTRAINT `user_game_preferences_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `user_game_preferences` ADD CONSTRAINT `user_game_preferences_gameId_games_id_fk` FOREIGN KEY (`gameId`) REFERENCES `games`(`id`) ON DELETE cascade ON UPDATE no action;