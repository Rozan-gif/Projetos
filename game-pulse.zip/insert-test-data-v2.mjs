import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';

// Parse DATABASE_URL
const dbUrl = new URL(process.env.DATABASE_URL);
const pool = mysql.createPool({
  host: dbUrl.hostname,
  port: dbUrl.port,
  user: dbUrl.username,
  password: dbUrl.password,
  database: dbUrl.pathname.slice(1),
  ssl: { rejectUnauthorized: false },
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

async function insertTestData() {
  const connection = await pool.getConnection();
  
  try {
    console.log('Conectando ao banco de dados...');
    console.log('Host:', dbUrl.hostname);
    console.log('Database:', dbUrl.pathname.slice(1));
    console.log('\nInserindo dados de teste...\n');

    // Limpar dados anteriores (opcional)
    // await connection.execute('DELETE FROM game_events');
    // await connection.execute('DELETE FROM feed_articles');
    // await connection.execute('DELETE FROM twitch_drops');

    // Inserir eventos
    const eventsSql = `
      INSERT INTO game_events (gameId, title, description, status, startDate, endDate, createdAt, updatedAt) VALUES
      (1, 'Campeonato Regional LoL 2026', 'Torneio regional com os melhores times', 'upcoming', DATE_ADD(NOW(), INTERVAL 5 DAY), DATE_ADD(NOW(), INTERVAL 15 DAY), NOW(), NOW()),
      (1, 'Patch 14.5 - Novos Campeões', 'Atualização com novos campeões e balanceamento', 'upcoming', DATE_ADD(NOW(), INTERVAL 2 DAY), DATE_ADD(NOW(), INTERVAL 2 DAY), NOW(), NOW()),
      (2, 'Fortnite Festival - Semana 3', 'Novos desafios e recompensas exclusivas', 'active', DATE_SUB(NOW(), INTERVAL 3 DAY), DATE_ADD(NOW(), INTERVAL 4 DAY), NOW(), NOW()),
      (3, 'CS2 Major Championship', 'Campeonato mundial de CS2', 'upcoming', DATE_ADD(NOW(), INTERVAL 10 DAY), DATE_ADD(NOW(), INTERVAL 20 DAY), NOW(), NOW())
    `;
    
    await connection.execute(eventsSql);
    console.log('✓ 4 eventos inseridos');

    // Inserir artigos
    const articlesSql = `
      INSERT INTO feed_articles (gameId, title, description, content, source, externalUrl, publishedAt, createdAt, updatedAt) VALUES
      (1, 'Novo campeão anunciado para League of Legends', 'Riot Games anuncia um novo campeão que chegará no próximo patch', 'Um novo campeão mágico chegará em breve ao Rift', 'Riot News', 'https://news.leagueoflegends.com', DATE_SUB(NOW(), INTERVAL 1 DAY), NOW(), NOW()),
      (1, 'Mudanças no sistema de rank 2026', 'Alterações significativas no sistema de classificação', 'O sistema de rank sofrerá mudanças importantes', 'Riot News', 'https://news.leagueoflegends.com', DATE_SUB(NOW(), INTERVAL 2 DAY), NOW(), NOW()),
      (2, 'Fortnite Season 6 - Novos locais', 'Explorar novos locais no mapa de Fortnite', 'A Season 6 traz novos pontos de interesse', 'Fortnite Blog', 'https://www.fortnite.com/news', DATE_SUB(NOW(), INTERVAL 3 DAY), NOW(), NOW()),
      (3, 'CS2 recebe novo mapa competitivo', 'Valve lança novo mapa para competições', 'Um novo mapa foi adicionado à rotação competitiva', 'CS2 News', 'https://www.counter-strike.net', DATE_SUB(NOW(), INTERVAL 4 DAY), NOW(), NOW()),
      (4, 'Marvel Rivals - Novo herói: Homem-Aranha', 'Homem-Aranha se junta ao elenco de heróis', 'O Homem-Aranha é o novo herói jogável', 'Marvel Rivals', 'https://www.marvelrivals.com/news', DATE_SUB(NOW(), INTERVAL 1 DAY), NOW(), NOW()),
      (5, 'Warhammer Darktide - Nova Missão', 'Missão especial com recompensas exclusivas', 'Uma nova missão foi adicionada ao jogo', 'Fatshark News', 'https://www.darktide.game', DATE_SUB(NOW(), INTERVAL 2 DAY), NOW(), NOW()),
      (6, 'Space Marine 2 - Atualização 2.5', 'Novo conteúdo e balanceamento de armas', 'Novos mapas e armas chegam ao jogo', 'Saber News', 'https://www.spacemarine2.game', DATE_SUB(NOW(), INTERVAL 3 DAY), NOW(), NOW())
    `;
    
    await connection.execute(articlesSql);
    console.log('✓ 7 artigos inseridos');

    // Inserir drops
    const dropsSql = `
      INSERT INTO twitch_drops (gameId, campaignId, title, description, rewards, status, startDate, endDate, watchUrl, createdAt, updatedAt) VALUES
      (1, 'lol-worlds-2026', 'LoL World Championship Drops', 'Ganhe skins exclusivas assistindo', '["Skin Exclusiva Worlds 2026"]', 'active', DATE_SUB(NOW(), INTERVAL 5 DAY), DATE_ADD(NOW(), INTERVAL 10 DAY), 'https://www.twitch.tv/directory/game/League%20of%20Legends', NOW(), NOW()),
      (2, 'fortnite-festival-2026', 'Fortnite Festival Drops', 'Recompensas exclusivas do Festival', '["Emote Raro Festival"]', 'active', DATE_SUB(NOW(), INTERVAL 2 DAY), DATE_ADD(NOW(), INTERVAL 7 DAY), 'https://www.twitch.tv/directory/game/Fortnite', NOW(), NOW()),
      (3, 'cs2-major-2026', 'CS2 Major Drops', 'Itens exclusivos do Major', '["Agente Exclusivo Major"]', 'upcoming', DATE_ADD(NOW(), INTERVAL 8 DAY), DATE_ADD(NOW(), INTERVAL 18 DAY), 'https://www.twitch.tv/directory/game/Counter-Strike%202', NOW(), NOW())
    `;
    
    await connection.execute(dropsSql);
    console.log('✓ 3 Twitch Drops inseridos');

    console.log('\n✅ Todos os dados de teste foram inseridos com sucesso!');
    console.log('\nAgora você pode:');
    console.log('1. Selecionar seus jogos favoritos no site');
    console.log('2. Ver os eventos, artigos e drops no dashboard');
    console.log('3. Testar os filtros e compartilhamento');

  } catch (error) {
    console.error('❌ Erro ao inserir dados:', error.message);
    if (error.sql) {
      console.error('SQL:', error.sql);
    }
  } finally {
    await connection.release();
    await pool.end();
  }
}

insertTestData();
